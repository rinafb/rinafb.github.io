source('IHT.R')
source('GL.R')
source('FS.R')

if(!require(utils)){
	install.packages('utils')
}
library('utils')
if(!require(xlsx)){
	install.packages('xlsx')
}
library('xlsx')
URL='http://www.countyhealthrankings.org/sites/default/files/state/downloads/2015%20County%20Health%20Rankings%20California%20Data%20-%20v1_0.xls';
rawdata=download.file(URL,'county_health_data.xls',mode='wb');
data=read.xlsx('county_health_data.xls', sheetName = 'Ranked Measure Data');
columns=c(5,10,15,20,27,32,36,40,42,47,50,56,59,63,68,73,77,81,85,90,95,100,104,110,113,117,
          123,128,131,134,138,141,144,150,155);
X=as.matrix(data[-1,columns]);
rownames(X)=NULL;
colnames(X)=NULL;
X=matrix(as.numeric(X),nrow(X),ncol(X));

index=apply(is.na(X),1,sum);
newX=X[index==0,-1];
y=log(X[index==0,1]);
myindex=1:ncol(newX);
model=lm(y~newX+1);
sigmahat=summary(model)$sigma;

y=y-mean(y);
X=scale(newX);
n=nrow(X);
p=ncol(X);

variables=data[1,columns];
variables=variables[-1];
variables=unname(as.matrix(variables));


# Case 1 : group size equal to 1 

k=8;
step=8;
lambda=0.8;
alpha=0.05;
G=p;

result_FS=FS(X,y,G,step,sigma=sigmahat,alpha=alpha);
pval_FS=result_FS$pval;
pval_FS_seq=result_FS$pval_seq;
select_FS=result_FS$select;

result_GL=GL(X,y,G,lambda,sigma=sigmahat,alpha=alpha);
pval_GL=result_GL$pval;

result_IHT=IHT(X,y,G,k,lr=1,TT=10,sigma=sigmahat);
pval_IHT=result_IHT$pval;


FS_results = (cbind(variables[select_FS],pval_FS_seq,pval_FS[select_FS]))
colnames(FS_results) = c('variable','seq p-value','p-value')
print('FS results (group size 1)');print(FS_results)

GL_results = (cbind(variables[!is.na(pval_GL)],pval_GL[!is.na(pval_GL)]))
GL_results = GL_results[order(pval_GL[!is.na(pval_GL)]),];colnames(GL_results) = c('variable','p-value')
print('GL results (group size 1)');print(GL_results)

IHT_results = (cbind(variables[!is.na(pval_IHT)],pval_IHT[!is.na(pval_IHT)]))
IHT_results = IHT_results[order(pval_IHT[!is.na(pval_IHT)]),];colnames(IHT_results) = c('variable','p-value')
print('IHT results (group size 1)');print(IHT_results)

# Case 2 : group size equal to 3 

X=X/max(abs(X));
l=3;
newX=X;
newX=rbind(newX,apply(X,2, function(x) (3*x^2-1)/2));
newX=rbind(newX,apply(X,2,function(x) (5*x^3-3*x)/2));
newX=matrix(newX,nrow=n,ncol=l*p,byrow=F);

k=8;
step=8;
lambda=0.25;
alpha=0.05;
G=p;

result_FS=FS(newX,y,G,step,sigma=sigmahat,alpha=alpha);
pval_FS=result_FS$pval;
pval_FS_seq=result_FS$pval_seq;
select_FS=result_FS$select;

result_GL=GL(newX,y,G,lambda,sigma=sigmahat,alpha=alpha);
pval_GL=result_GL$pval;

result_IHT=IHT(newX,y,G,k,lr=1,TT=10,sigma=sigmahat);
pval_IHT=result_IHT$pval;



FS_results = (cbind(variables[select_FS],pval_FS_seq,pval_FS[select_FS]))
colnames(FS_results) = c('variable','seq p-value','p-value')
print('FS results (group size 3)');print(FS_results)


GL_results = (cbind(variables[!is.na(pval_GL)],pval_GL[!is.na(pval_GL)]))
GL_results = GL_results[order(pval_GL[!is.na(pval_GL)]),];colnames(GL_results) = c('variable','p-value')
print('GL results (group size 3)');print(GL_results)


IHT_results = (cbind(variables[!is.na(pval_IHT)],pval_IHT[!is.na(pval_IHT)]))
IHT_results = IHT_results[order(pval_IHT[!is.na(pval_IHT)]),];colnames(IHT_results) = c('variable','p-value')
print('IHT results (group size 3)');print(IHT_results)



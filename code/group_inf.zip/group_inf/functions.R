# computing target of interests for group effect size when controlling for a selected model
# Input:
# X: design matrix
# y: response 
# mu: true mean of y
# CI: confidence interval returned by function GL or IHTGL;
# Output:
# a list containing two elements: truemean and trueinner, two targets of interests

verifyCI=function(X,y,mu,CI){
  n=nrow(X);
  p=ncol(X);
  G=length(CI);
  m=p/G;
  truemean=rep(NA,G);
  trueinner=rep(NA,G);
  temp=1:G;
  select=temp[!is.na(CI)];
  ls=length(select);
  for (i in 1:ls){
    g0=select[i];
    X0=X[,rep(1:G,each=m)==g0];
    XSh0 = X[,is.element(rep(1:G,each=m),setdiff(select,g0))]
    X0perp = X0 - XSh0%*%solve(t(XSh0)%*%XSh0,t(XSh0)%*%X0);
    Z = sqrt(t(t(X0perp)%*%mu)%*%solve(t(X0perp)%*%X0perp,t(X0perp)%*%mu));
    dir_y_proj = X0perp%*%solve(t(X0perp)%*%X0perp,t(X0perp)%*%y); dir_y_proj = dir_y_proj/sqrt(sum(dir_y_proj^2))
    truemean[g0]=Z;
    trueinner[g0]=sum(dir_y_proj*mu)
  }
  return(list('truemean'=truemean,'trueinner'=trueinner))
}


# making p-value plot
pvalue_scatter=function(pval,tk,xtick){
  G=ncol(pval);
  Nulls=pval[,-(1:tk)];
  Nulls=Nulls[!is.na(Nulls)];
  Trues=pval[,1:tk];
  Trues=Trues[!is.na(Trues)];
  
  laymat=matrix(c(2,1,3),nrow=1,byrow=T);
  layout(laymat,widths=c(1/6,2/3,1/6));
  par(mar=c(4,1,2,1),mgp=c(2,1,0))
  matplot(1:G,t(pval[,1:G]),type='p',col=1,cex=0.6,xlim=c(1,G),ylim=c(0,1.04),xlab='Group number (5 signals, 45 nulls)',ylab='',pch=20,bty='l',axes=FALSE)
  axis(side=1,at=xtick)
  axis(side=2,las=1)
  axis(side=4,las=1)
  matplot(1:tk,t(pval[,1:tk]),type='p',col=2,cex=0.6,add=T,pch=20)
  abline(v=(tk+0.5),col='darkgray',lty=2)
  text(tk/2,1.04,'Signals',cex=1)
  text((tk+G)/2,1.04,'Nulls',cex=1)
  
  nbin=10
  Signalhist=hist(Trues,plot=F,breaks=seq(0,1,by=1/nbin));
  Nullhist=hist(Nulls,plot=F,breaks=seq(0,1,by=1/nbin));
  par(mar=c(4,1,2,2))
  barplot(-(Signalhist$density),space=0,horiz=T,axes=F,col='red1',xlim=c(-max(Signalhist $density)*1.2,0),ylim=c(0,nbin*1.04))
  text(-max(Signalhist $density)*1.2,0.5,'Histogram of p-values (signals)',srt=90,pos=4)
  par(mar=c(4,2,2,1))
  barplot(Nullhist$density,space=0,horiz=T,axes=F,col='gray20',xlim=c(0,max(Nullhist$density)*1.2),ylim=c(0,nbin*1.04))
  text(max(Nullhist$density)*1.2,0.5,'Histogram of p-values (nulls)',srt=270,pos=2)
}

# making coverage plot
coverage_plot=function(tk,truemean,trueinner,CI,signal_list,alpha){
  eps=1e-10;
  sk=length(signal_list);
  coverage_norm=matrix(0,nrow=2,ncol=sk);
  coverage_inner=matrix(0,nrow=2,ncol=sk);
  for (i in 1:sk){
    tempCI_null=as.vector(CI[,-(1:tk),i]);
    tempCI_signal=as.vector(CI[,1:tk,i]);
    tempmean_null=as.vector(truemean[,-(1:tk),i]);
    tempmean_signal=as.vector(truemean[,1:tk,i]);
    tempinner_null=as.vector(trueinner[,-(1:tk),i]);
    tempinner_signal=as.vector(trueinner[,1:tk,i]);
    
    # norm
    flagnull=tempCI_null<tempmean_null;flagnull=flagnull[!is.na(flagnull)]
    coverage_norm[1,i]=sum(flagnull)/length(flagnull);
    
    flagsignal=tempCI_signal<tempmean_signal;flagsignal=flagsignal[!is.na(flagsignal)]
    coverage_norm[2,i]=sum(flagsignal)/length(flagsignal);
    
    # inner product
    flagnull=tempCI_null<tempinner_null;;flagnull=flagnull[!is.na(flagnull)]
    coverage_inner[1,i]=sum(flagnull)/length(flagnull);
    
    flagsignal=tempCI_signal<tempinner_signal;flagsignal=flagsignal[!is.na(flagsignal)]
    coverage_inner[2,i]=sum(flagsignal)/length(flagsignal);
    
  }
  y=t(rbind(coverage_norm[1,],coverage_inner[1,],coverage_norm[2,],coverage_inner[2,]));
  par(mar=c(3,4,1,1))
  ltys = c(2,1,2,1); cols = c('red','red','blue','blue'); pchs = c(1,1,8,8)
  matplot(signal_list,y,type='l',lty=ltys,col=cols,pch=pchs,xlab='Signal Strength',ylab='Empirical Coverage',las=1,ylim=c(0.8,1))
  matplot(signal_list,y,add=TRUE,lty=ltys,col=cols,pch=pchs)
  matplot(signal_list,y[,1:3],add=TRUE,col=cols[1:3],pch=pchs[1:3],xlab='Signal Strength',ylab='Empirical Coverage',las=1)
  legend('bottomright',c('Nulls (norm)', 'Nulls (inner product)','Signals (norm)','Signals (inner product)'),inset=0.01,lty=ltys,col=cols,pch=c(pchs,-1)) 
}



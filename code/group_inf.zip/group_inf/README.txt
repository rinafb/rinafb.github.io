Implementation:
* Implementation of the selective inference methods for forward stepwise regression: FS.R
* Implementation of the selective inference methods for iterative hard thresholding: IHT.R
* Implementation of the selective inference methods for the group lasso: GL.R

Simulation: this script reproduces the results in the paper (note that this script runs for several days in order to run multiple trials - to reset to a lower number of trials, modify the parameters B, B_GL, B_pvals).
* The script: simulation.R
* A few more functions needed for the simulations: functions.R
* The functions FS.R, IHT.R, GL.R from above are also required.

Real data experiment: this script reproduces the results in the paper using the county health data set (details on the data set: http://www.countyhealthrankings.org/).
* The script: healthdata_experiment.R
* The functions FS.R, IHT.R, GL.R from above are also required.
# m is the rank of supspace (generically should be group size)
# Z is the observed norm 
# finalinterval is R_Y
# alpha is the level controled
# maxL is the maximum considered L.
# output: L (left endpoint of CI)

BinarySearch=function(m,Z,finalintervals,alpha,tol=0.01,maxL=2*Z){
  err=1+tol;
  L_Upper=maxL;
  L_Lower=-m; 
  fl=length(finalintervals);
  leftend=finalintervals[seq(1,fl,2)];
  rightend=finalintervals[seq(2,fl,2)];
  ll=ceiling(fl/2);
  f1=rep(0,ll);
  f2=rep(0,ll);
  temp=which(leftend<=Z);
  posi=temp[length(temp)];
  while (err>tol){
    L=(L_Upper+L_Lower)/2;
    integrand<-function(r) {r^(m-1)*exp(-(r-L)^2/2)}
    for (i in 1:ll){
      f1[i]=integrate(integrand,leftend[i],rightend[i])$value;
      if (i<posi){
        next
      } else if (i==posi) {
        f2[i]=integrate(integrand,Z,rightend[i])$value;
      } else {
        f2[i]=f1[i];
      }
    }
    denominator=sum(f1);
    numerator=sum(f2);
    f=numerator/denominator-alpha;
    if ((f>=0) || is.nan(f) ){
      L_Upper=L;
    } else {
      L_Lower=L;
    }
    err=L_Upper-L_Lower;
  }
  return(L)
}


#  Construct union of finite intervals within [lower,upper] such that points
# between lowerset(i) and upperset(i) are excluded for all i.
unioninterval=function(lowerset,upperset,lower,upper){
  ll=length(lowerset);
  finterval=c(lower,upper);
  for (i in 1:ll){
    left=lowerset[i];
    right=upperset[i];
    temp1=which(finterval>=left);
    temp2=which(finterval<=right);
    if ((length(temp1)==0) || (length(temp2)==0)){
      next
    }
    index1=temp1[1];
    index2=temp2[length(temp2)];
    if (index1>1){
      LL=finterval[1:(index1-1)];
    } else {
      LL=c();
    }
    if (index2<length(finterval)){
      RR=finterval[-(1:index2)];
    } else {
      RR=c();
    }
    if ((index1%%2==0) && (index2%%2==0)){
      temp=c(LL,left,RR);
      finterval=temp;
      next
    }
    if ((index1%%2==1) && (index2%%2==0)){
      temp=c(LL,RR);
      finterval=temp;
      next
    }
    if ((index1%%2==0) && (index2%%2==1)){
      temp=c(LL,left,right,RR);
      finterval=temp;
      next
    }
    if ((index1%%2==1) && (index2%%2==1)){
      temp=c(LL,right,RR);
      finterval=temp;
    }
  }
  return(finterval)
}

# Forward Stepwise:
# input: 
# (X,y): data; 
# G: number of groups, where groups are assumed to have equal size and are in natural order
# step : Number of total steps
# alpha: (1-alpha) is the confidence level
# sigma: Standard deviation of error. Default is 1.

# Output:
# a list containing five elements: 
# pval_seq: a vector of length 'step' giving the p-values of each selected variable as it is selected
# pval: a vector of length G giving the p-values of each selected variable at the end of forward stepwise
# CI_seq: a vector of length 'step' giving the left endpoint of one-sided confidence interval for each selected variable as it is selected
# CI: a vector length G giving the left endpoint of one-sided confidence interval for each selected variable at the end of forward stepwise
# select: a vector indicating the selected group at each step. 

FS=function(X,y,G,step,sigma=1,alpha=0.05){
  p=ncol(X);
  m=p/G;
  pval_seq=rep(0,step); 
  pval=rep(NA,G);
  CI_seq=rep(0,step); 
  CI=rep(NA,G);
  select=rep(0,step);
  score=rep(0,G);
  
  # main loop for sequential pval and associated confidence interval
  XSh0=NULL;
  for (i in 1:step){
    if (i==1){
      resi=y;
    } else {
      resi=y-XSh0%*%solve(t(XSh0)%*%XSh0,t(XSh0)%*%y);
    }
    for (l in 1:G){
      score[l]=sqrt(sum((t(X[,(1:m)+m*(l-1)])%*%resi)^2));
    }
    select[i]=which.max(score);
    X0=X[,(1:m)+m*(select[i]-1)];
    # set direction u
    if (length(XSh0)==0){
      X0perp = X0;
    } else {
      X0perp = X0 - XSh0%*%solve(t(XSh0)%*%XSh0,t(XSh0)%*%X0);
    }
    u = X0perp%*%solve(t(X0perp)%*%X0perp,t(X0perp)%*%y)
    Z = sqrt(sum(u^2));
    u = u / Z;
    yperp = y - Z*u;
    # update XSh0
    XSh0=cbind(XSh0,X0);
    # constraints
    Z_lower = 0 # since it has to be positive
    Z_upper = Inf
    upperset=c();
    lowerset=c();
    for (j in 1:i){
      if (j==1){
        u1=u;
        yperp1=yperp;
      } else {
        XSh1=XSh0[,1:(m*(j-1))];
        u1= u-XSh1%*%solve(t(XSh1)%*%XSh1,t(XSh1)%*%u);
        yperp1=yperp-XSh1%*%solve(t(XSh1)%*%XSh1,t(XSh1)%*%yperp);
      }
      XS=XSh0[,(1:m)+m*(j-1)];
      for (g in 1:G){
        if (g %in% select[1:j]) next
        Xg=X[,(1:m)+m*(g-1)];
        a=sum((t(Xg)%*%u1)^2)-sum((t(XS)%*%u1)^2);
        b=2*(t(yperp1)%*%Xg%*%t(Xg)%*%u1-t(yperp1)%*%XS%*%t(XS)%*%u1);
        c=sum((t(Xg)%*%yperp1)^2)-sum((t(XS)%*%yperp1)^2);
        if (a>0){
          quadroot_plus = (-b+sqrt(b^2-4*a*c))/(2*a);
          quadroot_minus = (-b-sqrt(b^2-4*a*c))/(2*a);
          Z_lower = max(Z_lower,quadroot_minus);
          Z_upper = min(Z_upper,quadroot_plus);
        }
        if (a<0){
          if (b^2-4*a*c>0){
            quadroot_plus = (-b+sqrt(b^2-4*a*c))/(2*a);
            quadroot_minus = (-b-sqrt(b^2-4*a*c))/(2*a);
            upperset=c(upperset,quadroot_minus);
            lowerset=c(lowerset,quadroot_plus);
          }
        }
        if (a==0){
          if (b>0){
            Z_upper=min(Z_upper,-c/b);
          }
          if (b<0){
            Z_lower=max(Z_lower,-c/b);
          }
        }
         
      }
    }
    finalintervals=unioninterval(lowerset,upperset,Z_lower,Z_upper)/sigma;
    Z=Z/sigma;
    # do one-sided p-value
    fl=length(finalintervals);
    leftend=finalintervals[seq(1,fl,2)];
    rightend=finalintervals[seq(2,fl,2)];
    denominator=sum(pchisq(rightend^2,m)-pchisq(leftend^2,m));
    if (denominator==0){
      pval_seq[i]=0;
    } else {
      temp=which(leftend<=Z);
      posi=temp[length(temp)];
      numerator=sum(pchisq(rightend[posi:length(rightend)]^2,m)-pchisq(leftend[posi:length(leftend)]^2,m)) - (pchisq(Z^2,m)-pchisq(leftend[posi]^2,m));
      p1=numerator/denominator;
      pval_seq[i]=p1;
    }
    
    # do one-sided confidence interval
    L=sigma*BinarySearch(m,Z,finalintervals,alpha);
    CI_seq[i]=L;
    
  }
  
  # main loop for pval at the end of forward stepwise and associated confidence interval
  for (i in 1:step){
    X0=X[,(1:m)+m*(select[i]-1)];
    XSh = X[,is.element(rep(1:G,each=m),setdiff(select,select[i]))];
    if (length(XSh)==0){
      X0perp = X0;
    } else {
      X0perp = X0 - XSh%*%solve(t(XSh)%*%XSh,t(XSh)%*%X0); 
    }
    # choose direction u to test group select[i]
    u = X0perp%*%solve(t(X0perp)%*%X0perp,t(X0perp)%*%y)
    Z = sqrt(sum(u^2));
    u = u / Z;
    yperp = y - Z*u;
    # restrictions on z
    Z_lower = 0 # since it has to be positive
    Z_upper = Inf
    upperset=c();
    lowerset=c();
    XSh0=NULL;
    for (j in 1:step){
      XSh0=cbind(XSh0,X[,(1:m)+m*(select[j]-1)]);
      if (j==1){
        u1=u;
        yperp1=yperp;
      } else {
        XSh1=XSh0[,1:(m*(j-1))];
        u1= u-XSh1%*%solve(t(XSh1)%*%XSh1,t(XSh1)%*%u);
        yperp1=yperp-XSh1%*%solve(t(XSh1)%*%XSh1,t(XSh1)%*%yperp);
      }
      XS=XSh0[,(1:m)+m*(j-1)];
      for (g in 1:G){
        if (g %in% select[1:j]) next
        Xg=X[,(1:m)+m*(g-1)];
        a=sum((t(Xg)%*%u1)^2)-sum((t(XS)%*%u1)^2);
        b=2*(t(yperp1)%*%Xg%*%t(Xg)%*%u1-t(yperp1)%*%XS%*%t(XS)%*%u1);
        c=sum((t(Xg)%*%yperp1)^2)-sum((t(XS)%*%yperp1)^2);
        if (a>0){
          quadroot_plus = (-b+sqrt(b^2-4*a*c))/(2*a);
          quadroot_minus = (-b-sqrt(b^2-4*a*c))/(2*a);
          Z_lower = max(Z_lower,quadroot_minus);
          Z_upper = min(Z_upper,quadroot_plus);
        }
        if (a<0){
          if (b^2-4*a*c>0){
            quadroot_plus = (-b+sqrt(b^2-4*a*c))/(2*a);
            quadroot_minus = (-b-sqrt(b^2-4*a*c))/(2*a);
            upperset=c(upperset,quadroot_minus);
            lowerset=c(lowerset,quadroot_plus);
          }
        }
        if (a==0){
          if (b>0){
            Z_upper=min(Z_upper,-c/b);
          }
          if (b<0){
            Z_lower=max(Z_lower,-c/b);
          }
        }
        
      }
    }
    finalintervals=unioninterval(lowerset,upperset,Z_lower,Z_upper)/sigma;
    Z=Z/sigma;
    # do one-sided p-value
    fl=length(finalintervals);
    leftend=finalintervals[seq(1,fl,2)];
    rightend=finalintervals[seq(2,fl,2)];
    denominator=sum(pchisq(rightend^2,m)-pchisq(leftend^2,m));
    if (denominator==0){
      pval[select[i]]=0;
    } else {
      temp=which(leftend<=Z);
      posi=temp[length(temp)];
      numerator=sum(pchisq(rightend[posi:length(rightend)]^2,m)-pchisq(leftend[posi:length(leftend)]^2,m)) - (pchisq(Z^2,m)-pchisq(leftend[posi]^2,m));
      p1=numerator/denominator;
      pval[select[i]]=p1;
    }
    
    # do one-sided confidence interval
    L=sigma*BinarySearch(m,Z,finalintervals,alpha);
    CI[select[i]]=L;
    
  }
  
  return(list('pval_seq'=pval_seq,'pval'=pval,'CI_seq'=CI_seq,'CI'=CI,'select'=select))
  
}


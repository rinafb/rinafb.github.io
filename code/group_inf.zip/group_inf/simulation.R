# setting
source('functions.R')
source('IHT.R')
source('GL.R')
source('FS.R')

set.seed(1)

n = 500 # sample size
G = 50
m = 10 # G many groups, each of size m
tk = 5 # number of groups in the true model
alpha=0.1 # level controlled
B = 2000 ; B_GL = 200; B_pvals = 200 # run simulation for B times (or B_GL for group lasso) (B_pvals = how many to include in pvals plot)
signal_list=seq(from=1,to=10,by=0.5) # signal strength
nsig=length(signal_list);
sig_scatterplot_ind = 2; # which signal strength is used for the pvalue scatter plot

# parameters for IHT
lr=n/4; # learning rate (step size)
TT=5; # iteration times in IHT
k=10; # number of groups to select (choose to be greater than tk)
# parameters for GL
lambda=4; # penalty parameter
# parameters for FS
step=10; # number of groups to select (choose to be greater than tk)

pval_IHT=CI_IHT=truemean_IHT=trueinner_IHT=array(NA,c(B,G,nsig)); 

pval_GL=CI_GL=truemean_GL=trueinner_GL=array(NA,c(B_GL,G,nsig));

pval_FS=CI_FS=truemean_FS=trueinner_FS=array(NA,c(B,G,nsig));

# IHT
ptm=proc.time();
for (iter in 1:B){
  for (i in 1:nsig){
  # generate data
  X = matrix(rnorm(n*G*m),n,G*m)/sqrt(n)
  beta = rep(0,G*m); beta[1:(tk*m)] = signal_list[i];
  noise = rnorm(n);
  mu = X%*%beta;
  y = mu + noise;
  result=IHT(X,y,G,k,lr,alpha=alpha);
  targets=verifyCI(X,y,mu,result$CI);
  pval_IHT[iter,,i]=result$pval;
  CI_IHT[iter,,i]=result$CI;
  truemean_IHT[iter,,i]=targets$truemean;
  trueinner_IHT[iter,,i]=targets$trueinner;
  }
}
print('IHT complete')
proc.time()-ptm

# GL
ptm=proc.time();
for (iter in 1:B_GL){
  for (i in 1:nsig){
  # generate data
  X = matrix(rnorm(n*G*m),n,G*m)/sqrt(n)
  beta = rep(0,G*m); beta[1:(tk*m)] = signal_list[i];
  noise=rnorm(n);
  mu = X%*%beta;
  y = mu + noise;
  result=GL(X,y,G,lambda,alpha=alpha);
  targets=verifyCI(X,y,mu,result$CI);
  pval_GL[iter,,i]=result$pval;
  CI_GL[iter,,i]=result$CI;
  truemean_GL[iter,,i]=targets$truemean;
  trueinner_GL[iter,,i]=targets$trueinner;
  }
}
print('Group lasso complete')
proc.time()-ptm

# FS
ptm=proc.time();
for (iter in 1:B){
  for (i in 1:nsig){
  # generate data
  X = matrix(rnorm(n*G*m),n,G*m)/sqrt(n)
  beta = rep(0,G*m); beta[1:(tk*m)] = signal_list[i];
  noise=rnorm(n);
  mu = X%*%beta;
  y = mu + noise;
  result=FS(X,y,G,step,alpha=alpha);
  targets=verifyCI(X,y,mu,result$CI)
  pval_FS[iter,,i]=result$pval;
  CI_FS[iter,,i]=result$CI;
  truemean_FS[iter,,i]=targets$truemean;
  trueinner_FS[iter,,i]=targets$trueinner;
  }
}
print('Forward stepwise complete')
proc.time()-ptm

save(file='simulation_results.RData','pval_IHT','CI_IHT','truemean_IHT','trueinner_IHT','pval_GL','CI_GL','truemean_GL','trueinner_GL','pval_FS','CI_FS','truemean_FS','trueinner_FS')

pdf('IHT_pvalue_scatter.pdf',7,2.5)
pvalue_scatter(pval_IHT[1:B_pvals,,1],tk,xtick=c(1,seq(from=5,to=50,by=5)))
dev.off()
pdf('IHT_coverage_plot.pdf',10,3)
coverage_plot(tk,truemean_IHT,trueinner_IHT,CI_IHT,signal_list,alpha)
dev.off()

pdf('GL_pvalue_scatter.pdf',7,2.5)
pvalue_scatter(pval_GL[1:B_pvals,,sig_scatterplot_ind],tk,xtick=c(1,seq(from=5,to=50,by=5)))
dev.off()
pdf('GL_coverage_plot.pdf',10,3)
coverage_plot(tk,truemean_GL,trueinner_GL,CI_GL,signal_list,alpha)
dev.off()

pdf('FS_pvalue_scatter.pdf',7,2.5)
pvalue_scatter(pval_FS[1:B_pvals,,sig_scatterplot_ind],tk,xtick=c(1,seq(from=5,to=50,by=5)))
dev.off()
pdf('FS_coverage_plot.pdf',10,3)
coverage_plot(tk,truemean_FS,trueinner_FS,CI_FS,signal_list,alpha)
dev.off()



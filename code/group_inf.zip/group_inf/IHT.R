# m is the rank of supspace (generically should be group size)
# Z is the observed norm 
# finalinterval is R_Y
# alpha is the level controled
# maxL is the maximum considered L.
# output: L (left endpoint of CI)

BinarySearch=function(m,Z,finalintervals,alpha,tol=0.01,maxL=2*Z){
  err=1+tol;
  L_Upper=maxL;
  L_Lower=-m; 
  fl=length(finalintervals);
  leftend=finalintervals[seq(1,fl,2)];
  rightend=finalintervals[seq(2,fl,2)];
  ll=ceiling(fl/2);
  f1=rep(0,ll);
  f2=rep(0,ll);
  temp=which(leftend<=Z);
  posi=temp[length(temp)];
  while (err>tol){
    L=(L_Upper+L_Lower)/2;
    integrand<-function(r) {r^(m-1)*exp(-(r-L)^2/2)}
    for (i in 1:ll){
      f1[i]=integrate(integrand,leftend[i],rightend[i])$value;
      if (i<posi){
        next
      } else if (i==posi) {
        f2[i]=integrate(integrand,Z,rightend[i])$value;
      } else {
        f2[i]=f1[i];
      }
    }
    denominator=sum(f1);
    numerator=sum(f2);
    f=numerator/denominator-alpha;
    if ((f>=0) || is.nan(f) ){
      L_Upper=L;
    } else {
      L_Lower=L;
    }
    err=L_Upper-L_Lower;
  }
  return(L)
}


#  Construct union of finite intervals within [lower,upper] such that points
# between lowerset(i) and upperset(i) are excluded for all i.
unioninterval=function(lowerset,upperset,lower,upper){
  ll=length(lowerset);
  finterval=c(lower,upper);
  for (i in 1:ll){
    left=lowerset[i];
    right=upperset[i];
    temp1=which(finterval>=left);
    temp2=which(finterval<=right);
    if ((length(temp1)==0) || (length(temp2)==0)){
      next
    }
    index1=temp1[1];
    index2=temp2[length(temp2)];
    if (index1>1){
      LL=finterval[1:(index1-1)];
    } else {
      LL=c();
    }
    if (index2<length(finterval)){
      RR=finterval[-(1:index2)];
    } else {
      RR=c();
    }
    if ((index1%%2==0) && (index2%%2==0)){
      temp=c(LL,left,RR);
      finterval=temp;
      next
    }
    if ((index1%%2==1) && (index2%%2==0)){
      temp=c(LL,RR);
      finterval=temp;
      next
    }
    if ((index1%%2==0) && (index2%%2==1)){
      temp=c(LL,left,right,RR);
      finterval=temp;
      next
    }
    if ((index1%%2==1) && (index2%%2==1)){
      temp=c(LL,right,RR);
      finterval=temp;
    }
  }
  return(finterval)
}

# Iterative Hard Thresholding
# Input:
# X,y: design matrix and response
# G: number of groups, where groups are assumed to have equal size and are in natural order
# k: Positive user specified integer
# lr: Learning rate (step size)
# TT: Number of iterations in IHT
# w0: Initial point. Default is origin.
# sigma: Standard deviation of error. Default is 1.
# alpha: 1-alpha is the confidence level. Default is 0.05.
# Output:
# a list containing two elements: 
# pval: a vector of length G giving the p-values of each selected variable.(NA for Non-selected variable) 
# CI: a vector giving the left endpoint of one-sided confidence interval for each selected variable. (NA for Non-selected variable)

IHT=function(X,y,G,k,lr=2,TT=5,w0=rep(0,ncol(X)),sigma=1,alpha=0.05){
  n=nrow(X);
  p=ncol(X);
  m=p/G;
  select=matrix(0,nrow=TT,ncol=k);
  pval=rep(NA,G);
  CI=rep(NA,G);
  XtX=t(X)%*%X;
  #eps=1e-15;
  
  # implement IHT (get selected model)
  w=w0;
  for (i in 1:TT){
    g=w-(lr/n)*t(X)%*%(y-X%*%w);
    groupnorm=rep(0,G);
    for (j in 1:G){
      groupnorm[j]=sqrt(sum(g[(1:m)+m*(j-1)]^2));
    }
    ss=sort(groupnorm,decreasing=T,index.return=T);
    select[i,]=ss$ix[1:k];
    w=rep(0,G*m);
    for (l in 1:k){w[(1:m)+m*(select[i,l]-1)]=g[(1:m)+m*(select[i,l]-1)];}
  }
  
  #  do inference on each selected group
  Sh=select[TT,];
  for (g0 in Sh){ 
    X0=X[,(1:m)+m*(g0-1)];
    XSh0 = X[,is.element(rep(1:G,each=m),setdiff(Sh,g0))]; #all groups in Sh except for g0 
    X0perp = X0 - XSh0%*%solve(t(XSh0)%*%XSh0,t(XSh0)%*%X0) # project X0 = group g0, orthogonal to all other groups in Sh
    u = X0perp%*%solve(t(X0perp)%*%X0perp,t(X0perp)%*%y)
    Z = sqrt(sum(u^2));
    u = u / Z;
    yperp = y - Z*u;
    # restrictions on z
    Z_lower = 0 # since it has to be positive
    Z_upper = Inf
    upperset=c();
    lowerset=c();
    w=w0;
    ct=-(lr/n)*t(X)%*%u;
    dt=w-(lr/n)*t(X)%*%yperp+(lr/n)*t(X)%*%X%*%w;
    for (i in 1:TT){
      position=NULL; for (j in 1:k){position = c(position,(1:m)+m*(select[i,j]-1))};
      for (l1 in select[i,]){
        for (l2 in setdiff(1:G,select[i,])){
          c1=ct[(1:m)+m*(l1-1)];
          d1=dt[(1:m)+m*(l1-1)];
          c2=ct[(1:m)+m*(l2-1)];
          d2=dt[(1:m)+m*(l2-1)];
          # constaint is ||c1*Z+d1||>=||c2*Z+d2||
          a=sum(c1^2)-sum(c2^2);
          b=2*(sum(c1*d1)-sum(c2*d2));
          c=sum(d1^2)-sum(d2^2);
          if (a<0){
            #print(b^2-4*a*c)
            quadroot_plus = (-b+sqrt(b^2-4*a*c))/(2*a)
            quadroot_minus = (-b-sqrt(b^2-4*a*c))/(2*a)
            Z_lower = max(Z_lower,quadroot_plus)
            Z_upper = min(Z_upper,quadroot_minus)
          }
          if (a>0){
            if (b^2-4*a*c>0){
              quadroot_plus = (-b+sqrt(b^2-4*a*c))/(2*a);
              quadroot_minus = (-b-sqrt(b^2-4*a*c))/(2*a);
              upperset=c(upperset,quadroot_plus);
              lowerset=c(lowerset,quadroot_minus);
            }
          }
          if(a==0){
            if (b>0){
              Z_lower=max(Z_lower,-c/b);
            }
            if (b<-0){
              Z_upper=min(Z_upper,-c/b);
            }
          }
          
        }
      }
      # updata ct and dt
      ct[setdiff(1:(G*m),position)]=0;
      dt[setdiff(1:(G*m),position)]=0
      ct=-(lr/n)*t(X)%*%u+(lr/n*XtX+diag(G*m))%*%ct;
      dt=-(lr/n)*t(X)%*%yperp+(lr/n*XtX+diag(G*m))%*%dt;
      
    }
    finalintervals=unioninterval(lowerset,upperset,Z_lower,Z_upper)/sigma;
    Z=Z/sigma;
    
    # do one-sided p-value
    fl=length(finalintervals);
    leftend=finalintervals[seq(1,fl,2)];
    rightend=finalintervals[seq(2,fl,2)];
    denominator=sum(pchisq(rightend^2,m)-pchisq(leftend^2,m));
    if (denominator==0){
      pval[g0]=0;
    } else {
      temp=which(leftend<=Z);
      posi=temp[length(temp)];
      numerator=sum(pchisq(rightend[posi:length(rightend)]^2,m)-pchisq(leftend[posi:length(leftend)]^2,m)) - (pchisq(Z^2,m)-pchisq(leftend[posi]^2,m));
      p1=numerator/denominator;
      pval[g0]=p1;
    }
    
    # do one-sided confidence interval
      L=sigma*BinarySearch(m,Z,finalintervals,alpha);
      CI[g0]=L;
  }
  return(list('pval'=pval,'CI'=CI))
  
}
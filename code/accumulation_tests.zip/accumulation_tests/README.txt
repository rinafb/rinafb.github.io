Implementation:
* Implementation of the accumulation test methods: accumulation_test_functions.R

Demo: we create a sequence of hypotheses and p-values, and running accumulation test methods to test these hypotheses. This demo is implemented in R Markdown.
* View the code and results of the demo: ShortDemo.html or ShortDemo.pdf
* Download the R markdown file producing the demo: ShortDemo.Rmd (also requires accumulation_test_functions.R)
* Raw R code if using R rather than RStudio: ShortDemo.R (also requires accumulation_test_functions.R)

---

Reproduce the simulations:

Simulated sequences:
* View the code and results of the simulated sequence data experiment: simulation.html or simulation.pdf
* Download the R markdown file producing the demo: simulation.Rmd (also requires accumulation_test_functions.R)
* Raw R code if using R rather than RStudio: simulation.R (also requires accumulation_test_functions.R)

Simulated regression data:
* View the code and results of the simulated regression data experiment: simulation_regression.html or simulation_regression.pdf
* Download the R markdown file producing the demo: simulation_regression.Rmd (also requires accumulation_test_functions.R)

---

Reproduce the gene dosage data experiment:

* View the code and results of the gene dosage data experiment: gene_dosage_experiment.html or gene_dosage_experiment.pdf
* Download the R markdown file producing the demo: gene_dosage_experiment.Rmd (also requires accumulation_test_functions.R)
* Raw R code if using R rather than RStudio: gene_dosage_experiment.R (also requires accumulation_test_functions.R)



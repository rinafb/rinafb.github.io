#isotonic regression
source('isotonic_source.R')
#generate samples
pval_iso_d100_sig1 = list()
pval_iso_d100_sig4 = list()
pval_iso_d100_sig7 = list() 
theta0 =  sort(rep(seq(0.1, 1, 0.1), 10))
starttime = Sys.time()
for (i in 1:5000){
  #if (i%%500 == 1){
  #  print(i)
  #  print(Sys.time() - starttime) 
  #}
  seed = 100 + 2*i
  pval_iso_d100_sig1[[i]] = run_one_trial_iso(M = 300,seed, sigma = 1, d = 100,theta0)
  pval_iso_d100_sig4[[i]] = run_one_trial_iso(M = 300,seed, sigma = 4, d = 100,theta0)
  pval_iso_d100_sig7[[i]] = run_one_trial_iso(M = 300,seed, sigma = 7, d = 100, theta0)  
}
#power plot
alpha = 0.1
pvals = list(pval_iso_d100_sig1, pval_iso_d100_sig4, pval_iso_d100_sig7)
power_aCSS = list(rep(0, 11), rep(0, 11), rep(0, 11))
power_oracle= list(rep(0, 11), rep(0, 11), rep(0, 11))
power_aCSS_con= list(rep(0, 11), rep(0, 11), rep(0, 11))
for (k in 1:3){
  for (i in 1:5000){
    power_aCSS[[k]] = power_aCSS[[k]] + as.numeric(pvals[[k]][[i]][,2] < alpha)
    power_oracle[[k]] = power_oracle[[k]] + as.numeric(pvals[[k]][[i]][,1] < alpha) 
    power_aCSS_con[[k]] = power_aCSS_con[[k]] + as.numeric(pvals[[k]][[i]][,3] < alpha)
  }
}
power_aCSS = lapply(power_aCSS, function(x) x / 5000)  
power_aCSS_con = lapply(power_aCSS_con, function(x) x / 5000) 
power_oracle = lapply(power_oracle, function(x) x / 5000) 
signal = seq(from=0,to=0.5,by=0.05) 
plot_data <- data.frame(
  signal = rep(signal, times = 3 * 3),
  power = c(unlist(power_oracle), unlist(power_aCSS), unlist(power_aCSS_con)),
  method = rep(c("oracle", "aCSS", "reg-aCSS"), each = length(signal) * 3),
  sigma = c(rep(1, length(signal)), rep(4, length(signal)), rep(7, length(signal)))
)
plot_data$method <- factor(plot_data$method, levels = c("aCSS", "reg-aCSS", "oracle"))

#power
p <- ggplot(plot_data, aes(x = signal, y = power, color = sigma, linetype = method, lwd = 2)) +
  geom_line(aes(linetype = method, color = ifelse(method == "oracle", "black", sigma)), size = 0.5) +
  scale_color_manual(values = c("1" = "orange", "4" = "purple", "7" = "cyan"), name = expression(sigma))  +
  scale_linetype_manual(values = c("oracle" = "dashed", "aCSS" = "twodash", "reg-aCSS" = "solid")) +
  labs(x = expression(beta[0]), y = "power") +
  xlim(0, 0.5) +
  ylim(0, 1) +
  geom_hline(yintercept = alpha, linetype = "dotted", color = "red") +
  theme_bw()+
  theme(
    legend.text = element_text(size = 14),  # Font size for legend text
    legend.title = element_text(size = 16),  # Font size for legend title
    axis.title.x = element_text(size = 16),  # Font size for x-axis label
    axis.title.y = element_text(size = 16),  # Font size for y-axis label
    axis.text.x = element_text(size = 14),  # Font size for x-axis tick labels
    axis.text.y = element_text(size = 14)  # Font size for y-axis tick labels
  )
print(p) 
ggsave("power_iso_d100_147.pdf", p, width = 7, height = 5, units = "in") 
#type I error
sigmas = c(1,4,7)
data <- data.frame(
  sigma = rep(sigmas, 3),
  type1_error = c(
    unlist(lapply(power_oracle, function(x) x[[1]])),
    unlist(lapply(power_aCSS, function(x) x[[1]])),
    unlist(lapply(power_aCSS_con, function(x) x[[1]]))
  ),
  method = factor(rep(c("oracle", "aCSS", "reg-aCSS"), each = length(sigmas)))
)
data$method = factor(data$method, levels = c( "aCSS","reg-aCSS","oracle"))

# Calculate the confidence interval
data$delta <- sqrt(data$type1_error * (1 - data$type1_error) / 5000)
# New color set
color_set <- c( "steelblue", "darkorange","forestgreen")
# Create the ggplot with lines and bands
plot <- ggplot(data, aes(x = sigma, y = type1_error, color = method)) +
  geom_line(aes(linetype = method), size = 0.5) +
  geom_ribbon(aes(ymin = type1_error - delta, ymax = type1_error + delta, fill = method), alpha = 0.3, color = NA) + 
  # ylim(c(0, 0.2))+
  labs(  x = expression(sigma), y = "Type I Error") +
  theme_minimal() +
  scale_color_manual(values = color_set) +
  scale_fill_manual(values = color_set) +
  scale_linetype_manual(values = c('twodash', "solid", "dashed")) +
  geom_hline(yintercept = alpha, linetype = "dotted", color = "red", size = 0.5) +
  theme_bw()+
  theme(
    legend.text = element_text(size = 14),  # Font size for legend text
    legend.title = element_text(size = 16),  # Font size for legend title
    axis.title.x = element_text(size = 16),  # Font size for x-axis label
    axis.title.y = element_text(size = 16),  # Font size for y-axis label
    axis.text.x = element_text(size = 14),  # Font size for x-axis tick labels
    axis.text.y = element_text(size = 14)  # Font size for y-axis tick labels
  ) +
  scale_x_continuous(breaks = c(1, 4, 7)) 
print(plot)
ggsave('type1_iso_d100_147.pdf', plot, width = 7, height = 5, units = "in")
#p-value
data_aCSS <- data.frame(value = unlist(lapply(pval_iso_d100_sig7, function(x) x[1, 2])), method = "aCSS")
data_aCSScon <- data.frame(value = unlist(lapply(pval_iso_d100_sig7, function(x) x[1, 3])), method = "reg-aCSS")
data_combined <- rbind(data_aCSS, data_aCSScon)
breaks <- seq(0, 1, by = 0.1) 
p <- ggplot(data_combined, aes(x = value, fill = method)) +
  geom_histogram(aes(alpha = method), position = "identity", breaks = breaks) +
  scale_alpha_manual(values = c("aCSS" = 0.5, "reg-aCSS" = 0.5)) +
  scale_fill_manual(values = c("aCSS" = "blue", "reg-aCSS" = "red")) +
  labs(x = "Values", y = "Count" ) +
  xlim(0, 1) +
  theme_bw()+
  theme(
    legend.text = element_text(size = 14),  # Font size for legend text
    legend.title = element_text(size = 16),  # Font size for legend title
    axis.title.x = element_text(size = 16),  # Font size for x-axis label
    axis.title.y = element_text(size = 16),  # Font size for y-axis label
    axis.text.x = element_text(size = 14),  # Font size for x-axis tick labels
    axis.text.y = element_text(size = 14)  # Font size for y-axis tick labels
  ) 

print(p)
ggsave("histcompare_iso_d100_sig7.pdf", p, width = 7, height = 5)


#Sparse Regression
#generate samples
source('gaussian_linear_sparse_source.R')
M = 300
d = 100
n = 50
l1 = 2
l2 = 0.01 
isnorm = 1
theta0 = c(rep(0.5, 5), rep(0, d - 5))
power_d100_n50_sigma1 = power_d100_n50_sigma4 = power_d100_n50_sigma7= list()
for (i in 1:5000){
  if (i%%100 == 0){
    print(i)
    print(Sys.time() - starttime)
    starttime = Sys.time()
  }
  seed = 1000 + 2*i
  power_d100_n50_sigma1[[i]] = run_one_trial_gl(seed, M, d, sigma = 1, n, l1,l2, theta0, isnorm)
  power_d100_n50_sigma4[[i]] = run_one_trial_gl(seed, M, d, sigma =4, n, l1,l2, theta0, isnorm)
  power_d100_n50_sigma7[[i]] = run_one_trial_gl(seed, M, d, sigma =7, n, l1,l2, theta0, isnorm)
}
#power plot
alpha = 0.1
pvals = list(power_d100_n50_sigma1, power_d100_n50_sigma4,power_d100_n50_sigma7)
power_aCSS = list(rep(0, 6), rep(0, 6), rep(0, 6))
power_oracle= list(rep(0, 6), rep(0, 6), rep(0, 6))
power_aCSS_con= list(rep(0, 6), rep(0, 6), rep(0, 6))
for (k in 1:3){
  for (i in 1:5000){
    power_aCSS[[k]] = power_aCSS[[k]] + as.numeric(pvals[[k]][[i]][,2] < alpha)
    power_oracle[[k]] = power_oracle[[k]] + as.numeric(pvals[[k]][[i]][,1] < alpha) 
    power_aCSS_con[[k]] = power_aCSS_con[[k]] + as.numeric(pvals[[k]][[i]][,3] < alpha)
  }
}
power_aCSS = lapply(power_aCSS, function(x) x / 5000)  
power_aCSS_con = lapply(power_aCSS_con, function(x) x / 5000) 
power_oracle = lapply(power_oracle, function(x) x / 5000) 
signal = seq(from=0,to=1,by=0.2) 
#power
plot_data <- data.frame(
  signal = rep(signal, times = 3 * 3),
  power = c(unlist(power_oracle), unlist(power_aCSS), unlist(power_aCSS_con)),
  method = rep(c("oracle", "aCSS", "reg-aCSS"), each = length(signal) * 3),
  sigma = c(rep(1, length(signal)), rep(4, length(signal)), rep(7, length(signal)))
) 
plot_data$method <- factor(plot_data$method, levels = c("aCSS", "reg-aCSS", "oracle"))
p <- ggplot(plot_data, aes(x = signal, y = power, color = sigma, linetype = method, lwd = 2)) +
  geom_line(aes(linetype = method, color = ifelse(method == "oracle", "black", sigma)), size = 0.5) +
  scale_color_manual(values = c("1" = "orange", "4" = "purple", "7" = "cyan"), name = expression(sigma))  +
  scale_linetype_manual(values = c("oracle" = "dashed", "aCSS" = "twodash", "reg-aCSS" = "solid") ) +
  labs(x = expression(beta[0]), y = "power") +
  xlim(0, 1) +
  ylim(0, 1) +
  geom_hline(yintercept = alpha, linetype = "dotted", color = "red", size = 0.5) +
  theme_bw() +
  theme(
    legend.text = element_text(size = 14),  # Font size for legend text
    legend.title = element_text(size = 16),  # Font size for legend title
    axis.title.x = element_text(size = 16),  # Font size for x-axis label
    axis.title.y = element_text(size = 16),  # Font size for y-axis label
    axis.text.x = element_text(size = 14),  # Font size for x-axis tick labels
    axis.text.y = element_text(size = 14)  # Font size for y-axis tick labels
  )
print(p) 
ggsave("power_sparse_d100_147.pdf", p, width = 7, height = 5, units = "in") 
#type I error
sigmas = c(1,4,7)
data <- data.frame(
  sigma = rep(sigmas, 3),
  type1_error = c(
    unlist(lapply(power_oracle, function(x) x[[1]])),
    unlist(lapply(power_aCSS, function(x) x[[1]])),
    unlist(lapply(power_aCSS_con, function(x) x[[1]]))
  ), 
  method = rep(c("oracle", "aCSS", "reg-aCSS"), each = length(sigmas))
)
data$method = factor(data$method, levels = c( "aCSS","reg-aCSS","oracle"))

data$delta <- sqrt(data$type1_error * (1 - data$type1_error) / 5000) 
color_set <- c( "steelblue", "darkorange","forestgreen") 
plot <- ggplot(data, aes(x = sigma, y = type1_error, color = method)) +
  geom_line(aes(linetype = method), size = 0.5) +
  geom_ribbon(aes(ymin = type1_error - delta, ymax = type1_error +  delta, fill = method), alpha = 0.3, color = NA) +
  labs(x = expression(sigma), y = "Type I Error") +
  theme_minimal() + 
  scale_color_manual(values = color_set) +
  scale_fill_manual(values = color_set) +
  scale_linetype_manual(values = c('twodash', "solid", "dashed")) +
  geom_hline(yintercept = alpha, linetype = "dotted", color = "red", size = 0.5) +
  scale_x_continuous(limits = c(1, 7))+
  theme_bw() +
  theme(
    legend.text = element_text(size = 14),  # Font size for legend text
    legend.title = element_text(size = 16),  # Font size for legend title
    axis.title.x = element_text(size = 16),  # Font size for x-axis label
    axis.title.y = element_text(size = 16),  # Font size for y-axis label
    axis.text.x = element_text(size = 14),  # Font size for x-axis tick labels
    axis.text.y = element_text(size = 14)  # Font size for y-axis tick labels
  )
print(plot)
ggsave('type1_sparse_d100_147.pdf', plot, width = 7, height = 5, units = "in")
#histogram for pvals
data_aCSS <- data.frame(value = unlist(lapply(power_d100_n50_sigma7, function(x) x[1, 2])), method = "aCSS")
data_aCSScon <- data.frame(value = unlist(lapply(power_d100_n50_sigma7, function(x) x[1, 3])), method = "reg-aCSS")
data_combined <- rbind(data_aCSS, data_aCSScon)
breaks <- seq(0, 1, by = 0.1) 
p <- ggplot(data_combined, aes(x = value, fill = method)) +
  geom_histogram(aes(alpha = method), position = "identity", breaks = breaks) +
  scale_alpha_manual(values = c("aCSS" = 0.5, "reg-aCSS" = 0.5)) +
  scale_fill_manual(values = c("aCSS" = "blue", "reg-aCSS" = "red")) +
  labs(x = "Values", y = "Count" ) +
  xlim(0, 1) +
  theme_bw() +
  theme(
    legend.text = element_text(size = 14),  # Font size for legend text
    legend.title = element_text(size = 16),  # Font size for legend title
    axis.title.x = element_text(size = 16),  # Font size for x-axis label
    axis.title.y = element_text(size = 16),  # Font size for y-axis label
    axis.text.x = element_text(size = 14),  # Font size for x-axis tick labels
    axis.text.y = element_text(size = 14)  # Font size for y-axis tick labels
  )
print(p)
ggsave("histcompare_sparse_d100_sig7.pdf", p, width = 7, height = 5)



 


#mixture gaussian
source('mixtureGaussian_source.R')
library(parallel)  
exp_mixg = function(npval){
  run_one_trial(M = 300,seed = 1000 + 2*npval)
} 
pval_mixturegaussian_sig8 <- mclapply(1:500, exp_mixg) 

alpha = 0.05
poracle= rep(0,8)
pacss = rep(0,8)  
for (i in 1:500){
  poracle = poracle + as.numeric(pval_mixturegaussian_sig8[[i]][,1] < alpha)
  pacss = pacss + as.numeric(pval_mixturegaussian_sig8[[i]][,2] < alpha) 
}
poracle = poracle/500
pacss = pacss/500 

signal = seq(from=0,to=0.21,by=0.03)
df <- data.frame(
  signal = rep(signal, times = 2),
  power = c( poracle, pacss),
  method =  rep(c("oracle",  "aCSScon"), each = length(signal)))

 
p <- ggplot(df, aes(x = signal, y = power, linetype = method, lwd = 2)) +
  geom_line(aes(linetype = method), size = 0.5) +
  scale_linetype_manual(values = c("oracle" = "dashed", "C-aCSS" = "solid")) +
  labs(x =  expression(pi[0]), y = "power") +
  xlim(0, 0.2) +
  ylim(0, 1) +
  geom_hline(yintercept = alpha, linetype = "dotted", color = "red") +
  theme_bw()+
  theme(
    legend.text = element_text(size = 14),  # Font size for legend text
    legend.title = element_text(size = 16),  # Font size for legend title
    axis.title.x = element_text(size = 16),  # Font size for x-axis label
    axis.title.y = element_text(size = 16),  # Font size for y-axis label
    axis.text.x = element_text(size = 14),  # Font size for x-axis tick labels
    axis.text.y = element_text(size = 14)  # Font size for y-axis tick labels
  ) 
# Save the plot to a PDF file
ggsave("mixturegaussian_0404_sig8_alpha05.pdf", p, width = 8, height = 5, units = "in") 


 




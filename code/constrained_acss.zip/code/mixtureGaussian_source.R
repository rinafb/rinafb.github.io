library(mixtools)
generate_parameters = function(){
  parameters = list()
  parameters$d = 5
  parameters$theta0 = c(0.5, 0.4, 0.1, -0.4, 0.1)
  parameters$third_center = 0
  parameters$third_sd = 0.1
  parameters$sigma = 8 
  parameters$tol = 0.01  #for ssosp check 
  parameters$signal = seq(from=0,to=0.21,by=0.03)
   
  parameters$try_mcmc_params = seq(from=2,to=10,by=2) 
  parameters$try_mcmc_params_ntrial = 100
  
  # example specific parameters
  parameters$example = list()
  parameters$example$n = 200 
  parameters$example$lb = 0.098
  parameters$example$numstep_mult = 2 
  parameters$example$numstep_max = 2000   
  parameters$example$acceptance_prob_min = 0.05    
  parameters$example$mcmc_params =  5
  parameters
}

generate_experiment = function(isignal,parameters){
  experiment = list() 
  X = rnormmix(parameters$example$n, c(parameters$signal[isignal], (1 - parameters$signal[isignal])/2, (1 - parameters$signal[isignal])/2), c(parameters$third_center, parameters$theta0[2],parameters$theta0[4]), c(parameters$third_sd, parameters$theta0[3],parameters$theta0[5]))
  experiment$X = X  
  experiment
}

generate_X_null = function(theta,parameters,experiment){
  X = rnormmix(parameters$example$n, c(theta[1], 1-theta[1]), c(theta[2],theta[4]), c(theta[3],theta[5]))
  X
}


Tfun = function(x,parameters,experiment){ 
  #kmeans(x, 2)$tot.withinss 
  kmeans_2 = kmeans(x,2,nstart = 30)
  kmeans_3 = kmeans(x,3,nstart = 30)
  (kmeans_2$tot.withinss - kmeans_3$tot.withinss)/kmeans_2$tot.withinss
}
 
negloglik = function(x,theta,parameters,experiment){
  temp = log(theta[1]*exp(dnorm(x, theta[2], theta[3], log = TRUE)) + (1-theta[1])*exp(dnorm(x, theta[4], theta[5], log = TRUE)))
  temp[temp==-Inf] = .Machine$double.eps
  -sum(temp)
}



gradient = function(x,theta,parameters,experiment){ 
  div = theta[1]*dnorm(x, theta[2], theta[3]) + (1-theta[1])*dnorm(x, theta[4], theta[5])
  div = pmax(div,.Machine$double.eps)
  g1 = sum((dnorm(x, theta[2], theta[3]) - dnorm(x, theta[4], theta[5]))/div)
  g2 = sum((theta[1]*dnorm(x, theta[2], theta[3])*(x - theta[2])/theta[3]**2)/div)
  g3 = sum(theta[1]*dnorm(x, theta[2], theta[3])*((x - theta[2])**2/theta[3]**3 - 1/theta[3])/div)
  g4 = sum((1-theta[1])*dnorm(x, theta[4], theta[5])*(x - theta[4])/theta[5]**2/div)
  g5 = sum((1-theta[1])*dnorm(x, theta[4], theta[5])*((x - theta[4])**2/theta[5]**3 - 1/theta[5])/div)
  c(-g1, -g2, -g3, -g4, -g5)
}

hessian = function(x,theta,parameters,experiment){
  div = theta[1]*dnorm(x, theta[2], theta[3]) + (1-theta[1])*dnorm(x, theta[4], theta[5])
  div = pmax(div,sqrt(.Machine$double.eps))
  g1 = dnorm(x, theta[2], theta[3]) - dnorm(x, theta[4], theta[5])
  g2 = theta[1]*dnorm(x, theta[2], theta[3])*(x - theta[2])/theta[3]**2
  g3 = theta[1]*dnorm(x, theta[2], theta[3])*((x - theta[2])**2/theta[3]**3 - 1/theta[3])
  g4 = (1-theta[1])*dnorm(x, theta[4], theta[5])*(x - theta[4])/theta[5]**2
  g5 = (1-theta[1])*dnorm(x, theta[4], theta[5])*((x - theta[4])**2/theta[5]**3 - 1/theta[5])
  g11 = sum(g1**2/div**2)
  g12 = sum(g1*g2/div**2 - g2/theta[1]/div) 
  g13 = sum(g1*g3/div**2 - g3/theta[1]/div)
  g14 = sum(g1*g4/div**2 + g4/(1-theta[1])/div)
  g15 = sum(g1*g5/div**2 + g5/(1-theta[1])/div)
  g21 = g12
  g22 = sum(g2**2/div**2 - g2/div*((x-theta[2])/theta[3]**2 - 1/(x - theta[2])))
  g23 = sum(g2*g3/div**2 - g3/div*(x-theta[2])/theta[3]**2 + 2*g2/div/theta[3])
  g24 = sum(g2*g4/div**2)
  g25 = sum(g2*g5/div**2)
  g31 = g13
  g32 = g23
  g33 = sum(g3**2/div**2 + 2*g3/theta[3]/div - g2/div*(x-theta[2])/theta[3]**2*((x-theta[2])**2/theta[3]**2 - 3))
  g34 = sum(g3*g4/div**2)
  g35 = sum(g3*g5/div**2)
  g41 = g14
  g42 = g24
  g43 = g34
  g44 = sum(g4**2/div**2 - g4/div*((x-theta[4])/theta[5]**2 - 1/(x - theta[4])))
  g45 = sum(g4*g5/div**2 - g5/div*(x-theta[4])/theta[5]**2 + 2*g4/div/theta[5])
  g51 = g15
  g52 = g25
  g53 = g35
  g54 = g45
  g55 = sum(g5**2/div**2 + 2*g5/theta[5]/div - g4/div*(x-theta[4])/theta[5]**2*((x-theta[4])**2/theta[5]**2 - 3))
  
  matrix(c(g11, g12, g13, g14, g15, 
           g21, g22, g23, g24, g25, 
           g31, g32, g33, g34, g35,
           g41, g42, g43, g44, g45,
           g51, g52, g53, g54, g55), 5)
}

thetahat_con = function(x,w,parameters,experiment){
  Lw = function(theta){ 
    negloglik(x,theta,parameters,experiment)+parameters$sigma*sum(w*theta)}
  gradLw = function(theta){gradient(x,theta,parameters,experiment)+parameters$sigma*w}
  #init = normalmixEM(x)
  invisible(capture.output(init <- normalmixEM(x)))
  
  theta_init = c(init$lambda[1],init$mu[1],init$sigma[1], init$mu[2],init$sigma[2])
  theta_init = pmax(theta_init, c(-100, -100, parameters$example$lb + 1e-6, -100, parameters$example$lb + 1e-6))
  optim(theta_init, Lw, gradLw, method='L-BFGS-B',lower=c(0.01,-1000,parameters$example$lb, -1000, parameters$example$lb), upper = c(0.99, 1000, 1000, 1000, 1000),control=list(factr=1e5))$par
   
}



thetahat = function(x,w,parameters,experiment){
  Lw = function(theta){ 
    negloglik(x,theta,parameters,experiment)+parameters$sigma*sum(w*theta)}
  gradLw = function(theta){gradient(x,theta,parameters,experiment)+parameters$sigma*w}
  init = normalmixEM(x)
  theta_init = c(init$lambda[1],init$mu[1],init$sigma[1], init$mu[2],init$sigma[2])
  optim(theta_init, Lw, gradLw, method='L-BFGS-B', control=list(factr=1e5))$par
  
}

check_SSOSP_con = function(x,w,theta,parameters,experiment){
  # Checks the minimum eigenvalue of the Hessian is positive 
  # and that the gradient is within a small tolerance of zero
  inactiveind = which(abs(theta - parameters$example$lb) > parameters$tol/10)
  (min(eigen(hessian(x,theta,parameters,experiment))$values)>0) &    
    (sum((gradient(x,theta,parameters,experiment)[inactiveind]+parameters$sigma*w[inactiveind])^2)<=parameters$tol)
}

generate_copies = function(M,thetah,mcmc_params,mcmc_numstep,parameters,experiment, W){
  g = gradient(experiment$X,thetah,parameters,experiment)+parameters$sigma*W
  hub = mcmc_con(experiment$X,g,thetah,mcmc_params,mcmc_numstep,parameters,experiment)
  Xcopies = list()
  for(m in 1:M){
    Xcopies[[m]] = mcmc_con(hub$x, g,thetah,mcmc_params,mcmc_numstep,parameters,experiment)$x
  }
  Xcopies
}

mcmc_con = function(x_init,g, theta,mcmc_params,mcmc_numstep,parameters,experiment){
  x = x_init 
  num_moves = 0
  for(step in 1:mcmc_numstep){
    x_new  = mcmc_proposal_draw(x, theta,mcmc_params,parameters,experiment)
    acceptance_prob = mcmc_acceptance_prob_con(x,x_new, g,theta,mcmc_params,parameters,experiment)
    accept = (runif(1) <= acceptance_prob)
    if(accept){
      x = x_new 
      num_moves = num_moves + 1
    }
  }
  output = list()
  output$x = x 
  output$num_moves = num_moves
  output
}


mcmc_proposal_draw = function(x,theta,mcmc_params,parameters,experiment){
  S = sample(parameters$example$n,mcmc_params)
  x_new = x
  x_new[S] = generate_X_null(theta,parameters,experiment)[S]
  x_new
}

mcmc_acceptance_prob_con = function(x,x_new,g,theta,mcmc_params,parameters,experiment){ 
  inactiveind = which(abs(theta - parameters$example$lb) > parameters$tol) 
  w_new  = (g-gradient(x_new,theta,parameters,experiment))/parameters$sigma
  thetah_new = thetahat_con(x_new,w_new,parameters,experiment)
  check = check_SSOSP_con(x_new,w_new,thetah_new,parameters,experiment)&(sum(((thetah_new)-theta)^2)<=parameters$tol)
  if(check){
    acceptance_prob = min(1,                                                                                                                                                                  
                          c( exp(-sum((g- gradient(x_new,theta,parameters,experiment))^2)/(2*parameters$sigma^2/parameters$d))/
                               exp(-sum((g - gradient(x,theta,parameters,experiment))^2)/(2*parameters$sigma^2/parameters$d)) *
                               det(as.matrix(hessian(x_new,theta,parameters,experiment)[inactiveind,inactiveind]))/det(as.matrix(hessian(x,theta,parameters,experiment)[inactiveind,inactiveind]))))
  }else{
    acceptance_prob = 0
  }
  acceptance_prob
}

choose_mcmc_params_con = function(theta,parameters,experiment){
  num_accept = rep(0,length(parameters$try_mcmc_params))
  num_trial = 0 
  for(itrial in 1:parameters$try_mcmc_params_ntrial){
    x = generate_X_null(theta,parameters,experiment)
    w = rnorm(parameters$d)/sqrt(parameters$d)
    thetah = thetahat_con(x,w,parameters,experiment) 
    if(check_SSOSP_con(x,w,thetah,parameters,experiment)){ 
      g = gradient(x,thetah,parameters,experiment)+parameters$sigma*w
      num_trial = num_trial + 1 
      for(iparam in 1:length(parameters$try_mcmc_params)){
        out = mcmc_con(x, g, thetah, parameters$try_mcmc_params[iparam],1,parameters,experiment)
        num_accept[iparam] = num_accept[iparam] + out$num_moves 
      }
    }
  }
  choose_mcmc_params_rule(num_accept,num_trial,parameters,experiment)
}

choose_mcmc_params_rule = function(num_accept,num_trial,parameters,experiment){
  avg_accept = num_accept/num_trial
  #avg_newsample = avg_accept * unlist(parameters$try_mcmc_params)
  avg_newsample = avg_accept * parameters$try_mcmc_params
  avg_newsample_clip = avg_newsample; avg_newsample_clip[which(avg_accept<parameters$example$acceptance_prob_min)] = -Inf
  iparam_best = which.max(avg_newsample_clip)
  output = list()
  #output$mcmc_params = list()
  output$avg_accept = avg_accept
  output$mcmc_params = parameters$try_mcmc_params[iparam_best]
  output$mcmc_numstep = min(parameters$example$numstep_max, round(parameters$example$numstep_mult / (avg_newsample[iparam_best]/parameters$example$n)))
  output
}







run_one_trial = function(M,seed,lb){
  starttime = Sys.time()
  set.seed(seed) 
  parameters = generate_parameters()
  parameters$example$lb = lb
  nsignal = length(parameters$signal)
  pval_aCSS = pval_oracle = rep(0,nsignal)
  for(isignal in 1:nsignal){
    print(c("signal", isignal)) 
    t1 = Sys.time()
    experiment = generate_experiment(isignal,parameters) 
    Tfun_ = function(x){Tfun(x,parameters,experiment)}
    # oracle method
    Xcopies = list()
    for(m in 1:M){
      Xcopies[[m]] = generate_X_null(parameters$theta0, parameters, experiment)
    }
    pval_oracle[isignal] = 
      (1+sum(unlist(lapply(Xcopies,Tfun_))>=Tfun_(experiment$X)))/(1+M)
    
    # aCSS method
    W = rnorm(parameters$d)/sqrt(parameters$d) 
    
    thetah = thetahat_con(experiment$X,W,parameters,experiment) 
    #print(thetah)
    if(check_SSOSP_con(experiment$X,W,thetah,parameters,experiment)){
      #print("SSOSP is TRUE")
      mcmc_params_tmp = choose_mcmc_params_con(thetah,parameters,experiment)
      mcmc_params = mcmc_params_tmp$mcmc_params
      mcmc_numstep = mcmc_params_tmp$mcmc_numstep  
      
      Xcopies = generate_copies(M,thetah,mcmc_params,mcmc_numstep,parameters,experiment, W)
   
      pval_aCSS[isignal] = (1+sum(unlist(lapply(Xcopies,Tfun_))>=Tfun_(experiment$X)))/(1+M)
     
    }else{
      #print("SSOSP is FALSE")
      pval_aCSS[isignal] = 1
    } 
    
    print(Sys.time() - t1)
    #print(c(pval_oracle[isignal], pval_aCSS[isignal]))
  }
  
  pvals = cbind(pval_oracle,pval_aCSS)
  colnames(pvals) = c('oracle','aCSS')
  rownames(pvals) = parameters$signal
  print(Sys.time() - starttime)
  print(Sys.time() - starttime)
  pvals
}

library(quadprog)
generate_parameters = function(sigma, d, theta0){
  parameters = list()
  parameters$d = d 
  parameters$sigma = sigma
  parameters$theta0 = theta0 
  parameters$tol = 1e-8 
  parameters$signal = seq(from=0,to=0.5,by=0.05) 
  
  # example specific parameters
  parameters$example = list()
  parameters$example$n = parameters$d 
  parameters$example$sigma_x = 1
  parameters$example$sigma_y = 1 
  parameters
}

generate_experiment = function(isignal,parameters){
  experiment = list()
  
  A = cbind(rep(0,parameters$d-1),diag(parameters$d-1)) + cbind(-1*diag(parameters$d-1), rep(0,parameters$d-1))
  X =  parameters$theta0 + parameters$example$sigma_x*rnorm(parameters$d)
  Y =  parameters$signal[isignal] * X + parameters$example$sigma_y*rnorm(parameters$d)  
  experiment$X = X
  experiment$A = A
  
  # example specific random variables
  experiment$example = list()
  experiment$example$Y = Y
  
  experiment
}

Tfun = function(x,parameters,experiment){
  abs(cor(x, experiment$example$Y))
}

generate_X_null = function(theta, parameters){
  theta + parameters$example$sigma_x*rnorm(parameters$d) 
}


 

gradient = function(x,theta,parameters){
  (theta - x)/parameters$example$sigma_x^2
} 

thetahat_con = function(x,w,parameters,experiment){
  solve.QP(diag(parameters$d), x - parameters$sigma*w, t(experiment$A), rep(0, parameters$d-1))$solution
}    

projection = function(theta,parameters,experiment){
  activeind = which(abs(theta[-1] - theta[-length(theta)]) < parameters$tol) 
  A0 = experiment$A[activeind,]
  pro_act = t(A0)%*%solve(A0%*%t(A0))%*%A0
  pro_inact = diag(parameters$d) - pro_act
  r = eigen(pro_inact)
  U = r$vectors[,which(abs(r$values) > parameters$tol)]
  pro = list()
  pro$activeind = activeind
  pro$pro_act = pro_act
  pro$pro_inact = pro_inact
  pro$U = U
  pro
}


check_SSOSP_con = function(x,w,theta,parameters,experiment){
  pro = projection(theta,parameters,experiment) 
  sum((pro$pro_inact%*%(gradient(x,theta,parameters)+parameters$sigma*w))^2)<=parameters$tol
}


generate_copies_acss = function(M,parameters,experiment, W){  
  mu = experiment$X - parameters$sigma*W
  Xcopies = list()
  for(m in 1:M){
    Xcopies[[m]] = mu + rnorm(parameters$d)/sqrt(1/parameters$example$sigma_x**2 + parameters$d/parameters$sigma**2)
  }
  Xcopies
  
}
 
generate_copies_acsscon = function(M,thetah,parameters,experiment, W){ 
  g = gradient(experiment$X,thetah,parameters)+parameters$sigma*W
  mu = thetah - (parameters$d*parameters$example$sigma_x**2/(parameters$sigma**2 + parameters$d*parameters$example$sigma_x**2))*g
  Xcopies = list()
  for(m in 1:M){
    Xcopies[[m]]  = mu + rnorm(parameters$d)/sqrt(1/parameters$example$sigma_x**2 + parameters$d/parameters$sigma**2)
  }
  Xcopies
  
}


run_one_trial_iso = function(M,seed,sigma,d, theta0){ 
  set.seed(seed) 
  parameters = generate_parameters(sigma, d, theta0)
  nsignal = length(parameters$signal)
  pval_aCSS_con = pval_oracle = pval_aCSS = rep(0,nsignal)
  for(isignal in 1:nsignal){ 
    experiment = generate_experiment(isignal,parameters) 
    Tfun_ = function(x){Tfun(x,parameters,experiment)}
    # oracle method
    Xcopies = list()
    for(m in 1:M){
      Xcopies[[m]] = generate_X_null(parameters$theta0, parameters)
    }
    pval_oracle[isignal] = 
      (1+sum(unlist(lapply(Xcopies,Tfun_))>=Tfun_(experiment$X)))/(1+M)
    
    Xcopies = list()
     
    
    # aCSS method
    W = rnorm(parameters$d)/sqrt(parameters$d) 
    
    Xcopies = generate_copies_acss(M,parameters,experiment, W) 
    pval_aCSS[isignal] = (1+sum(unlist(lapply(Xcopies,Tfun_))>=Tfun_(experiment$X)))/(1+M)
    
    thetah = thetahat_con(experiment$X,W,parameters,experiment) 
    if(check_SSOSP_con(experiment$X,W,thetah,parameters,experiment)){ 
      
      Xcopies = generate_copies_acsscon(M,thetah,parameters,experiment, W) 
      pval_aCSS_con[isignal] = (1+sum(unlist(lapply(Xcopies,Tfun_))>=Tfun_(experiment$X)))/(1+M)
    }else{ 
      pval_aCSS_con[isignal] = 1
    }
  }
  
  pvals = cbind(pval_oracle,pval_aCSS, pval_aCSS_con)
  colnames(pvals) = c('oracle','aCSS','aCSS_con')
  rownames(pvals) = parameters$signal
  
  pvals
}

 
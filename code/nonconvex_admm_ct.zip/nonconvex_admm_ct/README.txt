Code to reproduce the quantile regression example:
* nonconvex_admm_sparseQR.ipynb (Jupyter notebook)
* nonconvex_admm_sparseQR.html (html version)

Code to reproduce the CT image reconstruction simulation: 
* nonconvex_admm_CTsimulation.ipynb (Jupyter notebook)
* nonconvex_admm_CTsimulation.html (html version)
* scanner_layout.png - provides a figure needed to compile the notebook.
In addition to the simulation presented in the paper, this notebook also contains a version of the simulation with an added total variation penalty.

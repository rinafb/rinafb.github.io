source('pfilter.R') 
source('pfilter_new.R') 

# Benjamini-Hochberg procedure
Sh_BH = function(P,alpha){
  n = length(P); kh = max(0,which(sort(P)<=(1:n)/n*alpha))
  Sh = rep(0,n); Sh[which(P<=kh/n*alpha)]=1; Sh
}

# Benjamini & Bogomolov method using Simes test to screen for groups
Sh_BB = function(P,alpha,alpha_grp,grps){
  n = length(P); G = max(grps); Simes = rep(0,G)
  for(g in 1:G){
    Pg = P[which(grps == g)]; Simes[g] = min(sort(Pg) * length(Pg) / (1:length(Pg)))
  }
  kh_grp = max(0,which(sort(Simes)<=(1:G)/G*alpha_grp))
  alpha_adapt = alpha * kh_grp/G; Sh = rep(0,n)
  for(g in which(Simes<=kh_grp/G*alpha_grp)){
    Pg = P[which(grps == g)]
    khg = max(0,which(sort(Pg)<=(1:length(Pg))/length(Pg)*alpha_adapt))
    Sh[which(grps==g)[which(Pg<=khg/length(Pg)*alpha_adapt)]]=1}
  Sh
}



grpsize = 10
ngrp = 20
n = grpsize*ngrp
g0 = c(1:10,rep(0,ngrp-10)) # number of true signals per group
grps = kronecker(1:ngrp,rep(1,grpsize))
groups = cbind(1:n,grps)

groups_new = list(as.list(seq(grpsize*ngrp)),lapply(1:ngrp,function(x)(1:grpsize)+grpsize*(x-1)))
groups_new_BH = list(as.list(seq(grpsize*ngrp)))

alpha = 0.1; alpha_grp = 0.1
alphas = c(alpha,alpha_grp)
mu=2.5;sig=1

set.seed(11111)

Signals = rep(0,n)
for(g in 1:ngrp){
  Signals[(1:grpsize)+(g-1)*grpsize] = c(rep(1,g0[g]),rep(0,grpsize-g0[g]))
}
gSignals = rep(0,ngrp);
gSignals[g0>0]=1

P = 1-pnorm(rnorm(n)*(1*(1-Signals)+sig*Signals) + mu*Signals)
result_BB = Sh_BB(P,alpha,alpha_grp,grps)
result_BH = Sh_BH(P,alpha)
result_BH_newcode = pfilter_new(P,alpha,groups_new_BH)
result = pfilter(P,alphas,groups)
result_newcode = pfilter_new(P,alphas,groups_new)
WM=list();WM[[1]]=rep(1,n);WM[[2]]=c(rep((ngrp/10 + 1)*.5,10),rep(0.5,ngrp-10))
result_weighted = pfilter_new(P,alphas,groups_new,WM=WM)
result_adaptive = pfilter_new(P,alphas,groups_new,lambda=c(.5,.5))







matrixim=function(X,nr=grpsize,nc=ngrp){
  dim(X)=c(nr,nc)
  image(1-t(X),col=gray((0:10)/10),axes=FALSE)
  rect(0-1/2/nc,0-1/2/nr,1+1/2/nc,1+1/2/nr)
}

par(mfrow=c(4,2))
par(mar=c(0,0,4,0))
matrixim(Signals);title(main='True signals')
matrixim(result_BB);title(main='BB')
matrixim(result_BH);title(main='BH')
matrixim(result_BH_newcode);title(main='BH (new code)')
matrixim(result);title(main='p-filter')
matrixim(result_newcode);title(main='p-filter (new code)')
matrixim(result_weighted);title(main='p-filter+ (with weights on groups)')
matrixim(result_adaptive);title(main='p-filter+ (adaptive to null proportion)')

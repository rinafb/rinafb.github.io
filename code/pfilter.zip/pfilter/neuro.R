source("pfilter.R")

table = read.csv("fMRI_data.txt",skip=3)
# this data is obtained from:
# Leila Wehbe, Brian Murphy, Partha Talukdar, Alona Fyshe, Aaditya Ramdas, and Tom Mitchell. Simultaneously uncovering the patterns of brain regions involved in different story reading subprocesses. PLOS ONE, November Issue, 2014.

V = 41073 # number of voxels 
N = 287511 # V voxels x 7 time delays
# the first V many data points are at time delay 0sec, the next V are at time delay 2sec, ..., the last V are at time delay 12sec
d1 = 2 # index of the first time delay used
d2 = 4 # index of the last time delay used
first = d1*V + 1 # first data point at time d1
last = (d2+1)*V # last data point at time d2
numP = V*(d2-d1+1) # testing all V voxels at time delays d1,d1+1,...,d2

fullP = unlist(table[2],use.names=FALSE) # vector of all P-values
fullVoxels = rep(1:V,7) # labeling each data point with its voxel number
fullROIs = unlist(table[4],use.names=FALSE) # labeling each data point with its ROI number

P = fullP[first:last]; # vector of p-values

trivial = 1:numP; # first partition: each (voxel,time delay) is its own group
Voxels = fullVoxels[first:last]; # second partition: each voxel forms one group combining all time delays
ROIs = fullROIs[first:last]; # third partition: each ROI forms one group combining all voxels in that ROI at all time delays
ROIs_relabel = as.numeric(as.factor(ROIs)) # to make the ROI numbering consecutive - there are 78 ROIs present in this data but numbers range up to 90



alphas = 0.05
groups = trivial
Discoveries_BH = pfilter(P,alphas,groups) # BH procedure

alphas = c(0.05, 0.05, 0.1)
groups = cbind(trivial, Voxels, ROIs_relabel)
Discoveries_pfilter = pfilter(P,alphas,groups) # pfilter at the individual, voxel, & ROI level

write(Discoveries_BH,"neuro_output_BH.txt", ncolumns=1)
write(Discoveries_pfilter,"neuro_output_pfilter.txt", ncolumns=1)

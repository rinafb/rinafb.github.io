source('pfilter.R') 

# Benjamini-Hochberg procedure
Sh_BH = function(P,alpha){
	n = length(P); kh = max(0,which(sort(P)<=(1:n)/n*alpha))
	Sh = rep(0,n); Sh[which(P<=kh/n*alpha)]=1; Sh
}

# Benjamini & Bogomolov method using Simes test to screen for groups
Sh_BB = function(P,alpha,alpha_grp,grps){
	n = length(P); G = max(grps); Simes = rep(0,G)
	for(g in 1:G){
		Pg = P[which(grps == g)]; Simes[g] = min(sort(Pg) * length(Pg) / (1:length(Pg)))
	}
	kh_grp = max(0,which(sort(Simes)<=(1:G)/G*alpha_grp))
	alpha_adapt = alpha * kh_grp/G; Sh = rep(0,n)
	#for(g in which(Simes<=kh_grp*G/alpha_grp)){
	for(g in which(Simes<=kh_grp/G*alpha_grp)){
		Pg = P[which(grps == g)]
		khg = max(0,which(sort(Pg)<=(1:length(Pg))/length(Pg)*alpha_adapt))
		Sh[which(grps==g)[which(Pg<=khg/length(Pg)*alpha_adapt)]]=1}
	Sh
}



grpsize = 10
ngrp = 100
n = grpsize*ngrp
g0 = c(1:10,rep(0,ngrp-10)) # number of true signals per group
grps = kronecker(1:ngrp,rep(1,grpsize))
groups = cbind(1:n,grps)
alpha = 0.2; alpha_grp = 0.2
alphas = c(alpha,alpha_grp)
mu=3;sig=1
niter=100

set.seed(123)

Signals = rep(0,n)
for(g in 1:ngrp){
	Signals[(1:grpsize)+(g-1)*grpsize] = c(rep(1,g0[g]),rep(0,grpsize-g0[g]))
}
gSignals = rep(0,ngrp);
gSignals[g0>0]=1

P = 1-pnorm(rnorm(n)*(1*(1-Signals)+sig*Signals) + mu*Signals)
result = pfilter(P,alphas,groups)
result_BH = Sh_BH(P,alpha)
result_BB = Sh_BB(P,alpha,alpha_grp,grps)




matrixim=function(X,nr,nc){
	dim(X)=c(nr,nc)
	image(1-t(X),col=gray((0:10)/10),axes=FALSE)
	rect(0-1/2/nc,0-1/2/nr,1+1/2/nc,1+1/2/nr)
}

pdf('grouped_example.pdf',10,2.5)
par(mar=c(2,2,2,2))
par(mfrow=c(2,2))
matrixim(Signals,10,100);title(main='True signals')
matrixim(result,10,100);title(main='p-filter')
matrixim(result_BB,10,100);title(main='BB')
matrixim(result_BH,10,100);title(main='BH')
dev.off()



mulist = 1:5
nmu = length(mulist)

# record results: FDR, groupwise FDR, power, groupwise power
FDR = array(0,c(3,nmu,niter))
gFDR = array(0,c(3,nmu,niter))
power = array(0,c(3,nmu,niter))
gpower = array(0,c(3,nmu,niter))

for(imu in 1:nmu){mu = mulist[imu]
for(iter in 1:niter){
	P = 1-pnorm(rnorm(n)*(1*(1-Signals)+sig*Signals) + mu*Signals)
	result = pfilter(P,alphas,groups)
	result_BH = Sh_BH(P,alpha)
	result_BB = Sh_BB(P,alpha,alpha_grp,grps)
	results=cbind(result,result_BB,result_BH)
	gresults=results # grouped results
	dim(gresults)=c(10,100,3)
	gresults = (apply(gresults,2:3,sum)>0)
	for(method in 1:3){	
		FDR[method,imu,iter]=sum(results[,method]*(1-Signals))/max(1,sum(results[,method]))
		power[method,imu,iter]=sum(results[,method]*Signals)/sum(Signals)
		gFDR[method,imu,iter]=sum(gresults[,method]*(1-gSignals))/max(1,sum(gresults[,method]))
		gpower[method,imu,iter]=sum(gresults[,method]*gSignals)/sum(gSignals)
	}
}
}

pdf('grouped_results.pdf',10,4)
par(mfrow=c(2,2))
par(mar=c(3,4,1,2))
ltys=c(1,1,1)
lwds=c(1,1,1)
pchs=c(0,6,2)
cols=c('black','red','blue')
names=c('p-filter','BB','BH')
varnames=c('FDR','gFDR','power','gpower')
titles=c('By entry','By column','','')
ylabs=c('FDR','','Power','')
horizline=c(alpha,alpha_grp,0,0)
for(whichplot in 1:4){
	plot(mulist,mulist,ylab=ylabs[whichplot],xlab='',ylim=c(0,1),type='n',axes=FALSE,font.lab=2,cex.lab=1.2)
	axis(side=2)
	axis(side=1,at=1:5,lab=c(expression(paste(mu==1)),2:5))
	title(main=titles[whichplot])
	var=get(varnames[whichplot])
for(method in 1:3){
	points(mulist,rowMeans(var[method,,]),type='l',lty=ltys[method],lwd=lwds[method],col=cols[method])
	points(mulist,rowMeans(var[method,,]),pch=pchs[method],cex=1.3,col=cols[method])
}
if(horizline[whichplot]>0){abline(h=horizline[whichplot],lty=2)}
if(whichplot==1){legend(min(mulist),1,legend=names,lty=ltys,pch=pchs,lwd=lwds,cex=1.3,col=cols)}
}
dev.off()

pfilter_new = function(P,alphas,groups,W1 = NULL,UM = NULL,WM = NULL,lambda = NULL,betag = NULL,betam = NULL,betaminv = NULL){
  # P in [0,1]^n = vector of p-values
  # alphas in [0,1]^M = vector of target FDR levels
  # groups is a length M list of length G_m lists. 
  #	groups[[m]][g] = vector of indices of the p-values belonging to the g-th group in m-th layer
  #   (allows overlapping groups in layer m; allows indices that do not belong to a group in layer m)
  # W1 = length n vector, W1[i] = initial weight on i-th hypothesis
  # UM, WM = length M lists.
  #   UM[[m]] = vector of length G_m of penalty weights on each group in layer m
  #   WM[[m]] = vector of length G_m of prior weights on each group in layer m
  # lambda = length M vector of threshold for null proportion adaptivity in each layer
  #   (Storey's correction). (default = no null proportion adaptivity).
  # betag = length M list, betag[[m]][[g]] = reshaping function for group g in layer m
  #   (default = identity function)
  # betam = length M list, betam[[m]] = reshaping function for layer m
  #   (default = identity function)
  # betaminv = length M list, betaminv[[m]] = the inverse function of betam[[m]]
  #   (default = identity function)
  #   (note: if specifying functions for betam, need to also specify betaminv)
  
  
  # Initialize
  n = length(P)
  M = length(alphas)
  G = sapply(groups,function(x){length(x)})
  # G[m] = the # of groups in partition m
  L = sapply(groups, function(x){setdiff(seq(n),unique(unlist(x)))})
  # L[m] = the left-over set for each partition m
  
  # check for weights
  if(length(W1) == 0){W1 = rep(1,n)}
  if(length(UM) == 0){UM = list(); for(m in 1:M){UM[[m]] = rep(1,G[m])}}
  if(length(WM) == 0){WM = list(); for(m in 1:M){WM[[m]] = rep(1,G[m])}}
  # check for null proportion adaptivity
  if(length(lambda) == 0){lambda = rep(1,M)}
  # check for reshaping functions
  if(length(betag) == 0){betag = list()
  	for(m in 1:M){ betag[[m]] = list(); for(g in 1:G[m]){betag[[m]][[g]] = function(x){x}}}
  }
  if(length(betam) == 0){ betam = list(); for(m in 1:M){betam[[m]] = function(x){x}}}
  if(length(betaminv) == 0){ betaminv = list(); for(m in 1:M){betaminv[[m]] = function(x){x}}}
  
  # Weighting on individual level
  Q = P/W1
  
  # Get individual Simes
  # Simes[[m]][g] = Simes_{w^{(1)}}(A^m_g)                   
	Simes = list()
	for(m in 1:M){
		Simes[[m]]=rep(0,G[m])
		for(g in 1:G[m]){
			Simes[[m]][g]=min(sort(P[groups[[m]][[g]]])*
				length(groups[[m]][[g]])/(1:length(groups[[m]][[g]])))
		}
	}


  # Null adaptivity: calculate pih[m] for each layer = estimated proportion of null groups in layer m
  pih = lapply(
    seq(M),
    function(m){min(((UM[[m]]*WM[[m]])%*%as.array(Simes[[m]]>lambda[m])+
                       max((UM[[m]]*WM[[m]])))/(G[m]*(1-lambda[m])),1)})
  
  # Get threshhold of km for the rejection of each Simes test
  # this is the minimum k_m that we would need, in order to reject group #g in layer #m
  # i.e. g \in \Sh_m^{init}(k) iff k_m >= Simes_thresh[[m]][g]
  Simes_thresh = list()
  for(m in 1:M){
  	    Simes_thresh[[m]]=rep(0,G[m])
		for(g in 1:G[m]){
			if(Simes[[m]][g]>lambda[m]){Simes_thresh[[m]][[g]] = Inf}
                 else{Simes_thresh[[m]][[g]] = betaminv[[m]](
                   Simes[[m]][g]*pih[[m]]*G[m]/alphas[m]/WM[[m]][g])}
		}
  } 

  
  valid_thresh = lapply(seq(M),function(m)sort(Simes_thresh[[m]][Simes_thresh[[m]]<=G[m]],
         decreasing = TRUE,index.return=TRUE))
  valid_rej = lapply(seq(M),function(m)which(Simes_thresh[[m]]<=G[m]))
  
  
  # initialize 
  K = G # start at highest possible threshold, k_m = G_m for all m
  done = FALSE
  
  # compute current rejections by layer
  Shinitm=list() # Shinit[[m]] = Sh_m^{init}(k)
  Shinit=matrix(0,n,M) # Shinit[i,m] = 1{i \in L_m \cup (\cup_{g in Sh_m^{init}(k)} A^m_g) }

   for(m in 1:M){
    Shinitm[[m]] = which( Simes[[m]] <=
      pmin(alphas[m]*betam[[m]](K[m])/pih[[m]]/G[m]*WM[[m]],lambda[m]) )
    Shinit[c(L[[m]],unlist(groups[[m]][Shinitm[[m]]])),m] = 1
  }
  
  # run p-filter
  while(!done){
    kold = K
    for (m in 1:M) {
    	# at stage m, we fix k_{m'} for all m'\neq m, and may need to reduce k_m
    	# We have defined \Sh(k) =
    	# [L_m \cup (\cup_{g\in \Sh_m^{init}(k_m)} Amg)] \cap pass_Simes_others
    	# where pass_Simes_others =
    	# \cap_{m'\neq m} (L_{m'} \cup (\cup_g\in Sh_{m'}^{init}(k_{m'}) Am'g))

    	# first we calculate pass_Simes_others (note that this does *not* depend on k_m)
    	if(M==1){pass_Simes_others = 1:n}else{
    		pass_Simes_others = which(apply(Shinit[,-m,drop=FALSE],1,prod)==1)}
	     # Find the corresponding groups in layer m
         pass_Simes_others_group = NULL
         for (g in 1:G[m]){
            if (length(intersect(pass_Simes_others,groups[[m]][[g]]))){
             pass_Simes_others_group = c(pass_Simes_others_group,g)
            }
         }

		# now we need to find the largest possible k_m such that
		# \Sh_m(k) satisfies the fdp-hat constraint
		# i.e. sum_{g in Sh_m(k)} u^{(m)}_g >= k_m
		# i.e. sum_{g = 1}^{G_m} 1{Amg \cap \Sh(k) \neq 0} * u^{(m)}_g >= k_m      
		# i.e. sum_g 1{Amg \cap pass_Simes_others \neq 0} * 1{g in Sh_m^{init}(k_m)} * u^{(m)}_g >= k_m      
		# i.e. sum_{g \in pass_Simes_others_group} 1{g in Sh_m^{init}(k_m)} * u^{(m)}_g >= k_m      
		# i.e. sum_{g \in pass_Simes_others_group} 1{k_m >= Simes_thresh[[m]][g]} * u^{(m)}_g >= k_m      
		
	# we only need to consider those values of k_m which appear in Simes_thresh[[m]]
	# & also know that it cannot increase above the current k_m value = K[m]
	k_m_vals = c(sort(unique(Simes_thresh[[m]][Simes_thresh[[m]]<=K[m]]),decreasing=TRUE),0)
	ind = 1
	done_k_m = FALSE
	while(!done_k_m){
		k_m_new = k_m_vals[ind]
    	if(sum(UM[[m]][pass_Simes_others_group[Simes_thresh[[m]][pass_Simes_others_group]<=k_m_new]])>=k_m_new){ # this value of k_m is feasible
    		done_k_m = TRUE
    	}else{ind = ind+1} # this value of k_m is not feasible; go down to next highest value
    }  
    K[m] = k_m_new
    
    # update Sh^{init}
    Shinitm[[m]] = which( Simes[[m]] <=
      pmin(alphas[m]*betam[[m]](K[m])/pih[[m]]/G[m]*WM[[m]],lambda[m]) )
    Shinit[,m]=0; Shinit[c(L[[m]],unlist(groups[[m]][Shinitm[[m]]])),m] = 1



}

if(all(K==kold)){done = TRUE}

}

Sh = apply(Shinit,1,prod)
Sh
}

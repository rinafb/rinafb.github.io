Here we provide R code: a function implementing the p-filter method, and scripts for reproducing the two simulations and the real data experiment in the paper.

* The p-filter algorithm: pfilter.R (a simple example for how to use this function: example.R)

* Script for simulation 1 (grouped hypotheses, 100 trials): script_grouped.R (runs in ~30 seconds)

* Script for simulation 2 (row- and column-wise grouped hypotheses, 100 trials): script_row_col.R (runs in ~15 minutes)

* Script for the fMRI data experiment, neuro.R, and the fMRI data set, fMRI_data.txt.
This data is obtained from:
Leila Wehbe, Brian Murphy, Partha Talukdar, Alona Fyshe, Aaditya Ramdas, and Tom Mitchell. Simultaneously uncovering the patterns of brain regions involved in different story reading subprocesses. PLOS ONE, November Issue, 2014.

-----

Code implementing the more general version of the p-filter, allowing for null proportion adaptivity, weighting the p-values according to varying priors or penalties, overlapping groups, and incomplete partitions, can be found here:

* The p-filter algorithm: pfilter_new.R

* A test script to run the old & new versions of the algorithm: test_script.R
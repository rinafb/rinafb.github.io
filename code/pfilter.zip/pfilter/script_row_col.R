source('pfilter.R') 

# Benjamini-Hochberg procedure
Sh_BH = function(P,alpha){
	n = length(P); kh = max(0,which(sort(P)<=(1:n)/n*alpha))
	Sh = rep(0,n); Sh[which(P<=kh/n*alpha)]=1; Sh
}

# Benjamini & Bogomolov method using Simes test to screen for groups
Sh_BB = function(P,alpha,alpha_grp,grps){
	n = length(P); G = max(grps); Simes = rep(0,G)
	for(g in 1:G){
		Pg = P[which(grps == g)]; Simes[g] = min(sort(Pg) * length(Pg) / (1:length(Pg)))
	}
	kh_grp = max(0,which(sort(Simes)<=(1:G)/G*alpha_grp))
	alpha_adapt = alpha * kh_grp/G; Sh = rep(0,n)
#	for(g in which(Simes<=kh_grp*G/alpha_grp)){
	for(g in which(Simes<=kh_grp/G*alpha_grp)){
		Pg = P[which(grps == g)]
		khg = max(0,which(sort(Pg)<=(1:length(Pg))/length(Pg)*alpha_adapt))
		Sh[which(grps==g)[which(Pg<=khg/length(Pg)*alpha_adapt)]]=1}
	Sh
}



nr = 100
nc = 100
block1 = 15 # one block of signals
block2 = 15 # another block of signals
sparse = 15 # some additional signals in disjoint rows/columns
mu = 3
niter=100

set.seed(123)

Signals = matrix(0,nr,nc)
Signals[1:block1,1:block1] = 1
Signals[block1+(1:block2),block1+(1:block2)] = 1
diag(Signals[(block1+block2)+(1:sparse),(block1+block2)+(1:sparse)]) = 1
rSignals=rep(0,nr);rSignals[1:(block1+block2+sparse)]=1
cSignals=rep(0,nc);cSignals[1:(block1+block2+sparse)]=1



P = 1 - pnorm(Signals*mu + matrix(rnorm(nr*nc),nr,nc))

alpha = 0.2
alpha_grp = 0.2
alphas = c(alpha,alpha_grp,alpha_grp)
groups = cbind(1:(nr*nc),kronecker((1:nc),rep(1,nr)),kronecker(rep(1,nc),(1:nr)))
grps = kronecker(rep(1,nc),(1:nr))

result = pfilter(P,alphas,groups)
result_BH = Sh_BH(P,alpha)
result_BB = Sh_BB(P,alpha,alpha_grp,grps)



matrixim=function(X,nr,nc){
	# rotate X to suit the "image" display function
	dim(X)=c(nr,nc)
	X1 = matrix(0,nc,nr)
	for(i in 1:nr){for(j in 1:nc){X1[j,nr+1-i]=1 - X[i,j]}}
	image(X1,col=gray((0:10)/10),axes=FALSE)
	rect(0-1/2/nc,0-1/2/nr,1+1/2/nc,1+1/2/nr)
}

pdf('row_col_example.pdf',8,2)
par(mar=c(2,2,2,2))
par(mfrow=c(1,4))
matrixim(Signals,100,100);title(main='True signals')
matrixim(result,100,100);title(main='p-filter')
matrixim(result_BB,100,100);title(main='BB')
matrixim(result_BH,100,100);title(main='BH')
dev.off()



mulist = 1:5
nmu = length(mulist)

# record results: FDR, groupwise FDR, power, groupwise power
FDR = array(0,c(3,nmu,niter))
rFDR = array(0,c(3,nmu,niter))
cFDR = array(0,c(3,nmu,niter))
power = array(0,c(3,nmu,niter))
rpower = array(0,c(3,nmu,niter))
cpower = array(0,c(3,nmu,niter))

for(imu in 1:nmu){mu = mulist[imu]
for(iter in 1:niter){
	P = 1 - pnorm(Signals*mu + matrix(rnorm(nr*nc),nr,nc))
	result = pfilter(P,alphas,groups)
	result_BH = Sh_BH(P,alpha)
	result_BB = Sh_BB(P,alpha,alpha_grp,grps)
	results=cbind(result,result_BB,result_BH)
	rresults=results
	dim(rresults)=c(nr,nc,3)
	rresults = (apply(rresults,c(1,3),sum)>0)
	cresults=results
	dim(cresults)=c(nr,nc,3)
	cresults = (apply(cresults,c(2,3),sum)>0)
	for(method in 1:3){	
		FDR[method,imu,iter]=sum(results[,method]*(1-Signals))/max(1,sum(results[,method]))
		power[method,imu,iter]=sum(results[,method]*Signals)/sum(Signals)
		rFDR[method,imu,iter]=sum(rresults[,method]*(1-rSignals))/max(1,sum(rresults[,method]))
		rpower[method,imu,iter]=sum(rresults[,method]*rSignals)/sum(rSignals)
		cFDR[method,imu,iter]=sum(cresults[,method]*(1-cSignals))/max(1,sum(cresults[,method]))
		cpower[method,imu,iter]=sum(cresults[,method]*cSignals)/sum(cSignals)
	}
}
}

pdf('row_col_results.pdf',10,4)
par(mfrow=c(2,3))
par(mar=c(3,4,1,2))
ltys=c(1,1,1)
lwds=c(1,1,1)
pchs=c(0,6,2)
cols=c('black','red','blue')
names=c('p-filter','BB','BH')
varnames=c('FDR','rFDR','cFDR','power','rpower','cpower')
titles=c('By entry','By row','By column','','','')
ylabs=c('FDR','','','Power','','')
horizline=c(alpha,alpha_grp,alpha_grp,0,0,0)

for(whichplot in 1:6){
	plot(mulist,mulist,ylab=ylabs[whichplot],xlab='',ylim=c(0,1),type='n',axes=FALSE,font.lab=2,cex.lab=1.2)
	title(main=titles[whichplot])
	axis(side=2)
	axis(side=1,at=1:5,lab=c(expression(paste(mu==1)),2:5))
	var=get(varnames[whichplot])
for(method in 1:3){
	points(mulist,rowMeans(var[method,,]),type='l',lty=ltys[method],lwd=lwds[method],col=cols[method])
	points(mulist,rowMeans(var[method,,]),pch=pchs[method],cex=1.3,col=cols[method])
}
if(horizline[whichplot]>0){abline(h=horizline[whichplot],lty=3)}
if(whichplot==1){legend(min(mulist),1,legend=names,lty=ltys,lwd=lwds,pch=pchs,col=cols,cex=1.3)}
}
dev.off()

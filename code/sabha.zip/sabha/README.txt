
* Functions for computing data-adaptive weights: All_q_est_functions.R

* Script to reproduce the simulated data experiment (with low total variation structure on a 2D grid): simulation_2dTV.R
(In the first draft of the paper, the experiment was on a 1D chain graph: simulation_1dTV.R)

* Script to reproduce the gene/drug response real data experiment (with ordered structure): gene_drug_data_example.R

* Script to reproduce the fMRI real data experiment (with grouped structure): fMRI_data_example.R
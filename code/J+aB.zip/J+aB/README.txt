* Real data experiments: J+aB_code.ipynb (Jupyter notebook), J+aB_code.html (html version).
* See code for instructions for how to download the data sets
* Code for data preprocessing: get_meps_data.ipynb
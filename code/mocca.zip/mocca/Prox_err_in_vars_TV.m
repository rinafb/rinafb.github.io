function [obj,itercount,x] = Prox_err_in_vars_TV(Z,b,Del,nu,sigA,eps_or_k,eta,lam,niter)

% 1/2 x'*(Z'*Z - n*sigA^2*I)*x - x'*(Z'*b) + nu*||Del*x||_1

% lam = step size parameter

[n,d]=size(Z); m=size(Del,1);

    

x = zeros(d,1); xacc = zeros(d,1);
y = zeros(m,1); z = zeros(d,1);

obj = zeros(niter,1);
itercount = zeros(niter,1);

mat = (Z'*Z - n*sigA^2*eye(d));
Zb = Z'*b; count=0;
for iter=1:niter,

    x_gradstep = x - 1/eta*(mat*x-Zb); 
    x1 = x; y1=y;
    stop = false;
    count_inner=0;
    while(~stop),
        count=count+1;
        count_inner=count_inner+1;
        x1_old = x1;
        x1 = 1/(1+1/4/lam)*(x1+1/4/lam*x_gradstep - 1/4/lam*Del'*y1);
        y1 = min(max(y1+lam/2*Del*(2*x1-x1_old),-nu/eta),nu/eta);
        if(eps_or_k <1)
            if(norm(x1_old - x1)/norm(x1_old)<=eps_or_k)
                stop=true;
            end
        else
            if(count_inner==eps_or_k)
                stop=true;
            end
        end
    end
    x = x1; y = y1;
    obj(iter) = 1/2 * x'*mat*x - x'*Zb + nu*sum(abs(Del*x));
    itercount(iter)=count;
end


end
Here we provide MATLAB code for reproducing the two simulations in the MOCCA paper. 

Simulation 1 (nonconvex total variation penalty): this simulation compares two different implementations of MOCCA for a least squares regression problem with a nonconvex total variation penalty. The objective function is therefore a convex loss function plus a nonconvex penalty.
* The script to run our simulation: nonconvex_TV_script.m
* The script will call this function: MOCCA_nonconvex_TV.m

Simulation 2 (errors in variables with a total variation penalty): this simulation compares MOCCA against proximal gradient descent for a least squares regression problem with a (convex) total variation penalty, where only noisy versions of the regression variables are available. The objective function is therefore a nonconvex loss function plus a convex penalty.
* The script to run our simulation: err_in_vars_TV_script.m
* The script will call this function: Prox_err_in_vars_TV.m

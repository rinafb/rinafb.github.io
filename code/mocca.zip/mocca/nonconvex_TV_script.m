rng(1);

n=200;d=625;
d1=25; % 25 by 25 grid; d=d1^2
blocks=[5 15 5]; % x0 will be block diagonal (in 2D space)
amp=1;sig=1;
beta=3;nu=20;

A=randn(n,d);
x0=zeros(d1); 
start=0;
for i=1:length(blocks),
    x0(start+(1:blocks(i)),start+(1:blocks(i)))=amp;
    start = start+blocks(i);
end
x0=x0(:);
b=A*x0+sig*randn(n,1);

Del = zeros(d1*(d1-1)*2,d);
for i=1:(d1-1),
    start = (i-1)*2*d1;
    % point (i,j) to (i+1,j) for j=1,...,d1
    Del(start+(1:d1),(i-1)*d1+(1:d1))=eye(d1);
    Del(start+(1:d1),i*d1+(1:d1))=-eye(d1);
    % point (j,i) to (j,i+1) for j=1,...,d1
    Del(start+d1+(1:d1),((1:d1)-1)*d1+i)=eye(d1);
    Del(start+d1+(1:d1),((1:d1)-1)*d1+i+1)=-eye(d1);
end

% solving: min_x 1/2*||b-Ax||^2_2 + nu*sum_i beta log(1+|(Del*x)_i|/beta)

%%

lam_grid = 2.^(2:6);
niter=200;

nlam = length(lam_grid);

obj_MOCCA = zeros(niter,nlam);
check_optim_MOCCA = zeros(niter,nlam);
obj_MOCCA_split = zeros(niter,nlam);
check_optim_MOCCA_split = zeros(niter,nlam);

%%
% MOCCA
% tuning parameters: lam = step size tradeoff for primal vs dual steps

for ilam=1:nlam,
    [obj,check_optim,~] = MOCCA_nonconvex_TV(A,b,Del,nu,beta,lam_grid(ilam),niter,0);
    obj_MOCCA(:,ilam) = obj;
    check_optim_MOCCA(:,ilam) = check_optim;
end


%%
% MOCCA
% tuning parameters: lam = step size tradeoff for primal vs dual steps

for ilam=1:nlam,
    [obj,check_optim,~] = MOCCA_nonconvex_TV(A,b,Del,nu,beta,lam_grid(ilam),niter,1);
    obj_MOCCA_split(:,ilam) = obj;
    check_optim_MOCCA_split(:,ilam) = check_optim;
end

%%
figure;
subplot(2,2,1);lines=plot(log(obj_MOCCA));
xlabel('Iteration')
ylabel('log(Objective function value)')
axis([0 200 5 12])
title('MOCCA(natural)')
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('\lambda=4','\lambda=8','\lambda=16','\lambda=32','\lambda=64')

subplot(2,2,2);lines=plot(log(obj_MOCCA_split));
xlabel('Iteration')
ylabel('log(Objective function value)')
axis([0 200 5 12])
title('MOCCA(split)')
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('\lambda=4','\lambda=8','\lambda=16','\lambda=32','\lambda=64')

subplot(2,2,3);lines=plot(log(check_optim_MOCCA));
xlabel('Iteration')
ylabel('log(Change per iteration)')
axis([0 200 -2 7])
title('MOCCA(natural)')
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('\lambda=4','\lambda=8','\lambda=16','\lambda=32','\lambda=64')

subplot(2,2,4);lines=plot(log(check_optim_MOCCA_split));
xlabel('Iteration')
ylabel('log(Change per iteration)')
axis([0 200 -2 7])
title('MOCCA(split)')
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('\lambda=4','\lambda=8','\lambda=16','\lambda=32','\lambda=64')

set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperPosition', [2.5 2.5 10 8]);
print -depsc ../figs/nonconvex_TV.eps -r100

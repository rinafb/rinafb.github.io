function [obj,check_optim,x] = MOCCA_nonconvex_TV(A,b,Del,nu,beta,lam,niter,split)

% 1/2 ||b-Ax||^2 + nu * Pen(Del*x)
% where Pen(w) = sum_i beta *log(1+|w_i|/beta)

% lam = step size parameter

% we can write
% Pen(w) = ||w||_1 + h_{beta}(w)
% where h_{beta}(w) = Pen(w) - ||w||_1 is differentiable

% if split = 0: penalty term is kept in the dual (in the function F)
% F_conv(w)= nu*||w||_1
% F_diff(w)= h_{beta}(w)
% G_conv(x)= 1/2 ||b-A*x||^2_2
% G_diff(x)= 0

% if split = 1: penalty term is split over primal & dual (functions G & F)
% F_conv(w)= nu*||w||_1
% F_diff(w)= 0
% G_conv(x)= 1/2 ||b-A*x||^2_2
% G_diff(x)= h_{beta}(Del*x)

[~,d]=size(A); m=size(Del,1);

sig = lam/2*ones(m,1);
tau = 1/lam/4*ones(d,1);

x = zeros(d,1); xacc = zeros(d,1);
y = zeros(m,1); zG = zeros(d,1); zF = zeros(m,1);

obj = zeros(niter,1);
check_optim = zeros(niter,1);

for iter=1:niter,
    
    x_old = x; y_old = y;
    
    if(split==0)

        x = (diag(1./tau)+A'*A)\(-Del'*y+A'*b+x./tau);
        xacc = 2*x - x_old;

        y = min(max(y+sig.*(Del*xacc),...
              nu*(-zF./(beta+abs(zF)))-nu),...
                nu*(-zF./(beta+abs(zF)))+nu);

        zF = Del*xacc + (1./sig).*(y_old - y);

    else

        x = (diag(1./tau)+A'*A)\...
            (-Del'*y+nu*Del'*((Del*zG)./(beta+abs(Del*zG)))+A'*b+x./tau);
        xacc = 2*x-x_old;

        y = min(max(y+sig.*(Del*xacc),-nu),nu);
        
        zG = x;
    
    end
    
    obj(iter) = 1/2 * norm(b-A*xacc)^2 + nu*sum(beta*log(1+abs(Del*xacc)/beta));
    check_optim(iter) = sqrt(norm(x-x_old)^2+norm(y-y_old)^2);
     
end
x=xacc;

end
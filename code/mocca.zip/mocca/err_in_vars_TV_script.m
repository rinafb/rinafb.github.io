rng(1);

n=200;d=625;
d1=25; % 25 by 25 grid; d=d1^2
amp=1;sig=1;
nu=20;

A=randn(n,d);A = A/sqrt(mean(A(:).^2));sigA=0.2;Z=A+randn(n,d)*sigA;
x0=zeros(d1); 
start=0;
for i=1:length(blocks),
    x0(start+(1:blocks(i)),start+(1:blocks(i)))=amp;
    start = start+blocks(i);
end
x0=x0(:);
b=A*x0+sig*randn(n,1);


Del = zeros(d1*(d1-1)*2,d);
for i=1:(d1-1),
    start = (i-1)*2*d1;
    % point (i,j) to (i+1,j) for j=1,...,d1
    Del(start+(1:d1),(i-1)*d1+(1:d1))=eye(d1);
    Del(start+(1:d1),i*d1+(1:d1))=-eye(d1);
    % point (j,i) to (j,i+1) for j=1,...,d1
    Del(start+d1+(1:d1),((1:d1)-1)*d1+i)=eye(d1);
    Del(start+d1+(1:d1),((1:d1)-1)*d1+i+1)=-eye(d1);
end

% solving: min_x 1/2*x'*(Z'*Z-n*sigA^2*I)x - x'*(Z'*b) + nu*||Del*x||_1

%%
eta = 100;
lam = 100;
eta_conservative = 200;
lam_conservative = 200;

k_grid = [1 5];
eps_grid = [.1 .05 .02];
niter=200;

nk = length(k_grid);
neps = length(eps_grid);

obj_Prox = zeros(niter,nk+neps);
itercount_Prox = zeros(niter,nk+neps);
obj_Prox_conservative = zeros(niter,nk+neps);
itercount_Prox_conservative = zeros(niter,nk+neps);

% note: setting k = 1 yields the MOCCA algorithm

%%
% Proximal gradient descent
% tuning parameters: 
% eta = step size for gradient step
% lam = step size tradeoff for primal vs dual steps in TV prox
% eps = convergence threshhold for TV prox step *or* k = # TV prox steps

for i_eps_or_k=1:(neps+nk),
    if(i_eps_or_k <= nk)
        eps_or_k = k_grid(i_eps_or_k);
    else
        eps_or_k = eps_grid(i_eps_or_k - nk);
    end
    [obj,itercount,~] = ...
        Prox_err_in_vars_TV(Z,b,Del,nu,sigA,eps_or_k,eta,lam,niter);
    obj_Prox(:,i_eps_or_k) = obj;
    itercount_Prox(:,i_eps_or_k) = itercount;
    [obj,itercount,~] = ...
        Prox_err_in_vars_TV(Z,b,Del,nu,sigA,eps_or_k,eta_conservative,lam_conservative,niter);
    obj_Prox_conservative(:,i_eps_or_k) = obj;
    itercount_Prox_conservative(:,i_eps_or_k) = itercount;
end

%%
figure;
subplot(2,2,1);lines=plot(obj_Prox/1e4);
xlabel('Iteration')
ylabel('Objective function value (\times 10^4)')
title('Outer loop (does not reflect computational cost); \eta=\lambda=100')
axis([0 200 -2.2 0])
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('n_{step}=1 (MOCCA)','n_{step}=5','\epsilon_{thresh}=0.1','\epsilon_{thresh}=0.05','\epsilon_{thresh}=0.02')

subplot(2,2,2);lines=plot(itercount_Prox,obj_Prox/1e4);
xlabel('Iteration')
ylabel('Objective function value (\times 10^4)')
title('Inner loop (true computational cost); \eta=\lambda=100')
axis([0 1000 -2.2 0])
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('n_{step}=1 (MOCCA)','n_{step}=5','\epsilon_{thresh}=0.1','\epsilon_{thresh}=0.05','\epsilon_{thresh}=0.02')

subplot(2,2,3);lines=plot(obj_Prox_conservative/1e4);
xlabel('Iteration')
ylabel('Objective function value (\times 10^4)')
title('Outer loop (does not reflect computational cost); \eta=\lambda=200')
axis([0 200 -2.2 0])
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('n_{step}=1 (MOCCA)','n_{step}=5','\epsilon_{thresh}=0.1','\epsilon_{thresh}=0.05','\epsilon_{thresh}=0.02')

subplot(2,2,4);lines=plot(itercount_Prox_conservative,obj_Prox_conservative/1e4);
xlabel('Iteration')
ylabel('Objective function value (\times 10^4)')
title('Inner loop (true computational cost); \eta=\lambda=200')
axis([0 1000 -2.2 0])
set(lines(1),'Color',[0 0 1])
set(lines(2),'Color',[1 0 1])
set(lines(3),'Color',[0 0 0])
set(lines(4),'Color',[0 0.8 0.8])
set(lines(5),'Color',[1 0.5 0])
set(lines(1),'LineStyle','-')
set(lines(2),'LineStyle','-.')
set(lines(3),'LineStyle','--')
set(lines(4),'LineStyle',':')
set(lines(5),'LineStyle','--')
set(lines,'LineWidth',1.5)
set(lines(4),'LineWidth',3)
set(lines(5),'LineWidth',2.5)
legend('n_{step}=1 (MOCCA)','n_{step}=5','\epsilon_{thresh}=0.1','\epsilon_{thresh}=0.05','\epsilon_{thresh}=0.02')

set(gcf, 'PaperUnits', 'inches');
set(gcf, 'PaperPosition', [2.5 2.5 10 8]);
print -depsc ../figs/err_in_var_TV.eps -r100
